package com.wizzardnation.attendance

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
