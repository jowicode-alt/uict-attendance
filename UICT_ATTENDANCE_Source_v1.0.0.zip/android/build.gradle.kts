allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")

    // Firebase Auth 24.2 exposes Checker Framework type annotations in its
    // public Java signatures. Keep the annotation classes on the Kotlin
    // compiler classpath so release builds can resolve those inferred types.
    if (name == "firebase_auth") {
        pluginManager.withPlugin("com.android.library") {
            dependencies.add(
                "implementation",
                "org.checkerframework:checker-qual:3.43.0",
            )
        }
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
