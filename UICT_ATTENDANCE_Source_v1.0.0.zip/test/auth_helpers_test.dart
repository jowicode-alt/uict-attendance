import 'package:attendance/services/auth_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('authentication helpers', () {
    test('normalizes student numbers consistently', () {
      expect(
        AuthService.normalizeStudentNumber(' BBIT / 2026-004 '),
        'BBIT2026004',
      );
    });

    test('hashing is deterministic without exposing the input', () {
      final first = AuthService.hashValue('UICT-CODE-123');
      final second = AuthService.hashValue('UICT-CODE-123');
      expect(first, second);
      expect(first, isNot(contains('UICT-CODE-123')));
      expect(first.length, 64);
    });

    test('embedded profile photo stays below the Firestore document limit', () {
      expect(AuthService.maxEmbeddedPhotoBytes, 300000);
      expect(AuthService.maxEmbeddedPhotoBytes, lessThan(1024 * 1024));
    });
  });
}
