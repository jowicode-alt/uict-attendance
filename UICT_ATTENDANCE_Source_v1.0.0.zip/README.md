# UICT ATTENDANCE

Production Flutter attendance application for UICT BBIT, built for Android and iPhone with Firebase project `attendence-uict-bbit`. Release 1.0.0 removes Cloud Storage: compressed recognition photos are kept in the protected Firestore student profile, so the app can run on the no-cost Spark plan while usage remains within Firebase's free quotas.

Start with:

- `docs/CLIENT_HANDOVER.md`
- `docs/FIREBASE_SETUP.md`
- `docs/CLIENT_ACCEPTANCE_TEST.md`
- `docs/STORE_SUBMISSION_CHECKLIST.md`

## Local setup

1. Install Flutter 3.47.1 (or a compatible stable release), Android SDK 37, JDK 17, and Xcode for iOS work.
2. Copy `android/local.properties.example` to `android/local.properties` and set local paths.
3. Restore the private Android signing files when creating a release build.
4. Run:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
```

Open `ios/Runner.xcworkspace` on macOS for Apple signing and TestFlight/App Store distribution.
