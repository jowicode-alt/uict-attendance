import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';

enum UserRole { student, admin }

enum UserStatus { active, disabled, deleted }

class AppUser {
  const AppUser({
    required this.uid,
    required this.role,
    required this.fullName,
    required this.email,
    required this.phone,
    required this.status,
    this.studentNumber,
    this.photoBytes,
    this.deviceId,
    this.createdAt,
  });

  final String uid;
  final UserRole role;
  final String fullName;
  final String email;
  final String phone;
  final String? studentNumber;
  final Uint8List? photoBytes;
  final String? deviceId;
  final UserStatus status;
  final DateTime? createdAt;

  bool get isStudent => role == UserRole.student;
  bool get isAdmin => role == UserRole.admin;
  bool get isActive => status == UserStatus.active;

  factory AppUser.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    final role = data['role'] == 'admin' ? UserRole.admin : UserRole.student;
    final rawStatus = data['status'] as String? ?? 'active';
    final status = switch (rawStatus) {
      'disabled' => UserStatus.disabled,
      'deleted' => UserStatus.deleted,
      _ => UserStatus.active,
    };
    return AppUser(
      uid: document.id,
      role: role,
      fullName: data['fullName'] as String? ?? 'Unknown user',
      email: data['email'] as String? ?? '',
      phone: data['phone'] as String? ?? '',
      studentNumber: data['studentNumber'] as String?,
      photoBytes: (data['photoBytes'] as Blob?)?.bytes,
      deviceId: data['deviceId'] as String?,
      status: status,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }
}
