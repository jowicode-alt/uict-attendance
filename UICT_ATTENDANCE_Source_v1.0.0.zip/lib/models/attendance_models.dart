import 'package:cloud_firestore/cloud_firestore.dart';

class AttendanceSettings {
  const AttendanceSettings({
    required this.allowedWifiSsids,
    required this.radiusMeters,
    required this.campusName,
    this.campusLocation,
  });

  final List<String> allowedWifiSsids;
  final double radiusMeters;
  final String campusName;
  final GeoPoint? campusLocation;

  bool get isConfigured =>
      allowedWifiSsids.isNotEmpty && campusLocation != null && radiusMeters > 0;

  factory AttendanceSettings.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    return AttendanceSettings(
      allowedWifiSsids: List<String>.from(
        data['allowedWifiSsids'] as List<dynamic>? ?? const <dynamic>[],
      ),
      radiusMeters: (data['radiusMeters'] as num? ?? 100).toDouble(),
      campusName: data['campusName'] as String? ?? 'UICT BBIT Classroom',
      campusLocation: data['campusLocation'] as GeoPoint?,
    );
  }
}

class AttendanceSession {
  const AttendanceSession({
    required this.id,
    required this.title,
    required this.status,
    required this.openedBy,
    this.openedAt,
    this.closedAt,
    this.codeHash,
    this.currentQrHash,
  });

  final String id;
  final String title;
  final String status;
  final String openedBy;
  final DateTime? openedAt;
  final DateTime? closedAt;
  final String? codeHash;
  final String? currentQrHash;

  bool get isOpen => status == 'open';

  factory AttendanceSession.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    return AttendanceSession(
      id: document.id,
      title: data['title'] as String? ?? 'Attendance session',
      status: data['status'] as String? ?? 'closed',
      openedBy: data['openedBy'] as String? ?? '',
      openedAt: (data['openedAt'] as Timestamp?)?.toDate(),
      closedAt: (data['closedAt'] as Timestamp?)?.toDate(),
      codeHash: data['codeHash'] as String?,
      currentQrHash: data['currentQrHash'] as String?,
    );
  }
}

class AttendanceRecord {
  const AttendanceRecord({
    required this.id,
    required this.sessionId,
    required this.studentUid,
    required this.studentName,
    required this.studentNumber,
    required this.sessionTitle,
    required this.status,
    this.checkedAt,
  });

  final String id;
  final String sessionId;
  final String studentUid;
  final String studentName;
  final String studentNumber;
  final String sessionTitle;
  final String status;
  final DateTime? checkedAt;

  bool get isPresent => status == 'present';

  factory AttendanceRecord.fromDocument(
    QueryDocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data();
    return AttendanceRecord(
      id: document.id,
      sessionId: data['sessionId'] as String? ?? '',
      studentUid: data['studentUid'] as String? ?? document.id,
      studentName: data['studentName'] as String? ?? 'Unknown student',
      studentNumber: data['studentNumber'] as String? ?? '',
      sessionTitle: data['sessionTitle'] as String? ?? 'Attendance session',
      status: data['status'] as String? ?? 'absent',
      checkedAt: (data['checkedAt'] as Timestamp?)?.toDate(),
    );
  }
}
