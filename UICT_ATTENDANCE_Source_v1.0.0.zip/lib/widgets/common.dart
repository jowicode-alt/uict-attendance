import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../services/app_constants.dart';

class AppMark extends StatelessWidget {
  const AppMark({super.key, this.size = 72});
  final double size;

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(size * .22),
    child: Image.asset(
      'assets/images/uict_mark.png',
      width: size,
      height: size,
      fit: BoxFit.cover,
    ),
  );
}

class BrandBlock extends StatelessWidget {
  const BrandBlock({super.key, this.compact = false});
  final bool compact;

  @override
  Widget build(BuildContext context) => Column(
    children: [
      AppMark(size: compact ? 64 : 92),
      SizedBox(height: compact ? 12 : 18),
      Text(
        AppConstants.appName,
        style: Theme.of(context).textTheme.headlineSmall
            ?.copyWith(fontWeight: FontWeight.w900, letterSpacing: .4),
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 4),
      Text(
        AppConstants.organization,
        style: TextStyle(
          color: Theme.of(context).colorScheme.secondary,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
        ),
      ),
    ],
  );
}

class AppLoading extends StatelessWidget {
  const AppLoading({super.key, required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 18),
          Text(message),
        ],
      ),
    ),
  );
}

class BuiltByFooter extends StatelessWidget {
  const BuiltByFooter({super.key});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 18),
    child: Text(
      'Built by ${AppConstants.builtBy}',
      style: Theme.of(context).textTheme.labelSmall
          ?.copyWith(color: Colors.black45, letterSpacing: .8),
      textAlign: TextAlign.center,
    ),
  );
}

class UserPhoto extends StatelessWidget {
  const UserPhoto({
    super.key,
    required this.photoBytes,
    this.radius = 24,
    this.fallbackIcon = Icons.person,
  });

  final Uint8List? photoBytes;
  final double radius;
  final IconData fallbackIcon;

  @override
  Widget build(BuildContext context) {
    final bytes = photoBytes;
    final fallback = Icon(fallbackIcon, size: radius);
    return CircleAvatar(
      radius: radius,
      backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      child: ClipOval(
        child: bytes == null || bytes.isEmpty
            ? fallback
            : Image.memory(
                bytes,
                width: radius * 2,
                height: radius * 2,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => fallback,
              ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
  });

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(32),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 56, color: Colors.black38),
        const SizedBox(height: 14),
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium
              ?.copyWith(fontWeight: FontWeight.w800),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 6),
        Text(
          message,
          style: const TextStyle(color: Colors.black54),
          textAlign: TextAlign.center,
        ),
      ],
    ),
  );
}

void showMessage(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? Colors.red.shade700 : null,
      ),
    );
}

Future<bool> confirmAction(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Confirm',
  bool destructive = false,
}) async {
  return await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: destructive
                  ? FilledButton.styleFrom(backgroundColor: Colors.red.shade700)
                  : null,
              onPressed: () => Navigator.pop(context, true),
              child: Text(confirmLabel),
            ),
          ],
        ),
      ) ??
      false;
}
