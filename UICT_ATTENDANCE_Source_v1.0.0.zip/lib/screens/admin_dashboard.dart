import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/app_user.dart';
import '../models/attendance_models.dart';
import '../services/attendance_service.dart';
import '../services/auth_service.dart';
import '../widgets/common.dart';
import 'admin_management_page.dart';
import 'admin_reports_page.dart';
import 'admin_session_page.dart';
import 'admin_settings_page.dart';
import 'admin_students_page.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key, required this.user});
  final AppUser user;

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      AdminHome(admin: widget.user),
      const AdminStudentsPage(),
      const AdminReportsPage(),
      AdminMorePage(admin: widget.user),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(
          ['Administrator Dashboard', 'Students', 'Reports', 'More'][_index],
        ),
      ),
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            label: 'Students',
          ),
          NavigationDestination(
            icon: Icon(Icons.assessment_outlined),
            label: 'Reports',
          ),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class AdminHome extends StatelessWidget {
  const AdminHome({super.key, required this.admin});
  final AppUser admin;

  Future<void> _openSession(BuildContext context) async {
    final controller = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Open Attendance Session'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Module or session name',
            hintText: 'Example: Networking Fundamentals',
          ),
          onSubmitted: (value) {
            if (value.trim().isNotEmpty) Navigator.pop(context, value.trim());
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                Navigator.pop(context, controller.text.trim());
              }
            },
            child: const Text('Open Session'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (title == null || !context.mounted) return;
    try {
      final result = await AttendanceService.instance.openSession(title);
      if (!context.mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AdminSessionPage(
            sessionId: result.sessionId,
            initialCode: result.code,
            initialQrPayload: result.qrPayload,
          ),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      final message = error is AttendanceException
          ? error.message
          : error.toString();
      showMessage(context, message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<AttendanceSession>>(
    stream: AttendanceService.instance.sessionsStream(),
    builder: (context, sessionSnapshot) {
      final sessions = sessionSnapshot.data ?? const <AttendanceSession>[];
      final open = sessions.where((session) => session.isOpen).firstOrNull;
      return StreamBuilder<List<AppUser>>(
        stream: AttendanceService.instance.studentsStream(),
        builder: (context, studentSnapshot) {
          final students = studentSnapshot.data ?? const <AppUser>[];
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Card(
                color: Theme.of(context).colorScheme.primary,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 28,
                        backgroundColor: Colors.white.withValues(alpha: .15),
                        child: const Icon(
                          Icons.admin_panel_settings,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Welcome, Administrator',
                              style: TextStyle(color: Colors.white70),
                            ),
                            Text(
                              admin.fullName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 19,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: AdminMetricCard(
                      icon: Icons.groups_outlined,
                      value: '${students.length}',
                      label: 'Students',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AdminMetricCard(
                      icon: Icons.event_available_outlined,
                      value: '${sessions.length}',
                      label: 'Sessions',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              if (open == null)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Icon(Icons.event_available_outlined, size: 54),
                        const SizedBox(height: 10),
                        Text(
                          'No attendance session is open',
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Open a session when students are physically in class.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.black54),
                        ),
                        const SizedBox(height: 18),
                        FilledButton.icon(
                          onPressed: () => _openSession(context),
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('Open Attendance Session'),
                        ),
                      ],
                    ),
                  ),
                )
              else
                Card(
                  color: Colors.green.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.circle,
                              color: Colors.green,
                              size: 14,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'SESSION OPEN',
                              style: TextStyle(
                                color: Colors.green.shade800,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          open.title,
                          style: Theme.of(context).textTheme.titleLarge
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        if (open.openedAt != null)
                          Text(
                            'Opened ${DateFormat('dd MMM, HH:mm').format(open.openedAt!)}',
                            style: const TextStyle(color: Colors.black54),
                          ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  AdminSessionPage(sessionId: open.id),
                            ),
                          ),
                          icon: const Icon(Icons.qr_code_2),
                          label: const Text('Display QR and Code'),
                        ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 20),
              Text(
                'Recent sessions',
                style: Theme.of(context).textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              if (sessions.isEmpty)
                const Card(
                  child: ListTile(
                    leading: Icon(Icons.history),
                    title: Text('No sessions created yet'),
                  ),
                )
              else
                ...sessions
                    .take(5)
                    .map(
                      (session) => Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: Card(
                          child: ListTile(
                            leading: Icon(
                              session.isOpen
                                  ? Icons.radio_button_checked
                                  : Icons.event_available,
                              color: session.isOpen ? Colors.green : null,
                            ),
                            title: Text(
                              session.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: Text(
                              session.openedAt == null
                                  ? 'Time pending'
                                  : DateFormat('dd MMM yyyy, HH:mm')
                                        .format(session.openedAt!),
                            ),
                            trailing: Text(
                              session.status.toUpperCase(),
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 11,
                                color: session.isOpen
                                    ? Colors.green.shade700
                                    : Colors.black54,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
              const BuiltByFooter(),
            ],
          );
        },
      );
    },
  );
}

class AdminMetricCard extends StatelessWidget {
  const AdminMetricCard({
    super.key,
    required this.icon,
    required this.value,
    required this.label,
  });
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: Theme.of(context).textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w900),
              ),
              Text(label, style: const TextStyle(color: Colors.black54)),
            ],
          ),
        ],
      ),
    ),
  );
}

class AdminMorePage extends StatelessWidget {
  const AdminMorePage({super.key, required this.admin});
  final AppUser admin;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Card(
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.admin_panel_settings)),
          title: Text(
            admin.fullName,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          subtitle: Text(admin.email),
        ),
      ),
      const SizedBox(height: 14),
      Card(
        child: Column(
          children: [
            ListTile(
              leading: const Icon(Icons.location_on_outlined),
              title: const Text('Attendance Settings'),
              subtitle: const Text('Wi-Fi names, campus GPS and radius'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AdminSettingsPage()),
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('Administrator Management'),
              subtitle: const Text('Generate one-time registration codes'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AdminManagementPage()),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 18),
      OutlinedButton.icon(
        style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
        onPressed: AuthService.instance.signOut,
        icon: const Icon(Icons.logout),
        label: const Text('Log out'),
      ),
      const BuiltByFooter(),
    ],
  );
}
