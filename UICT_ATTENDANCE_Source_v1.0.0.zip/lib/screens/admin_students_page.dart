import 'package:flutter/material.dart';

import '../models/app_user.dart';
import '../services/attendance_service.dart';
import '../widgets/common.dart';

enum StudentAction { delete, resetPhone, toggleDisabled }

class AdminStudentsPage extends StatefulWidget {
  const AdminStudentsPage({super.key});

  @override
  State<AdminStudentsPage> createState() => _AdminStudentsPageState();
}

class _AdminStudentsPageState extends State<AdminStudentsPage> {
  String _search = '';

  Future<void> _runAction(AppUser student, StudentAction action) async {
    try {
      switch (action) {
        case StudentAction.resetPhone:
          final confirmed = await confirmAction(
            context,
            title: 'Reset registered phone?',
            message:
                '${student.fullName} will be allowed to bind the next phone used to log in. Their current phone registration will stop working.',
            confirmLabel: 'Reset Phone',
          );
          if (!confirmed) return;
          await AttendanceService.instance.resetStudentPhone(student.uid);
          if (mounted) {
            showMessage(context, 'Registered phone reset successfully.');
          }
        case StudentAction.toggleDisabled:
          final disabling = student.status != UserStatus.disabled;
          final confirmed = await confirmAction(
            context,
            title: disabling ? 'Disable student?' : 'Enable student?',
            message: disabling
                ? '${student.fullName} will not be able to use the app until enabled again.'
                : '${student.fullName} will regain access to the app.',
            confirmLabel: disabling ? 'Disable' : 'Enable',
            destructive: disabling,
          );
          if (!confirmed) return;
          await AttendanceService.instance.setStudentDisabled(
            student.uid,
            disabled: disabling,
          );
          if (mounted) {
            showMessage(
              context,
              disabling ? 'Student disabled.' : 'Student enabled.',
            );
          }
        case StudentAction.delete:
          final confirmed = await confirmAction(
            context,
            title: 'Delete student?',
            message:
                '${student.fullName} will permanently lose app access. Historical attendance records will be retained for reporting.',
            confirmLabel: 'Delete',
            destructive: true,
          );
          if (!confirmed) return;
          await AttendanceService.instance.deleteStudent(student.uid);
          if (mounted) showMessage(context, 'Student deleted.');
      }
    } catch (error) {
      if (mounted) showMessage(context, error.toString(), error: true);
    }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<AppUser>>(
    stream: AttendanceService.instance.studentsStream(),
    builder: (context, snapshot) {
      if (!snapshot.hasData) {
        return const Center(child: CircularProgressIndicator());
      }
      final query = _search.trim().toLowerCase();
      final students = snapshot.data!.where((student) {
        if (query.isEmpty) return true;
        return student.fullName.toLowerCase().contains(query) ||
            (student.studentNumber ?? '').toLowerCase().contains(query);
      }).toList();
      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 10),
            child: TextField(
              onChanged: (value) => setState(() => _search = value),
              decoration: InputDecoration(
                hintText: 'Search name or student number',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () => setState(() => _search = ''),
                        icon: const Icon(Icons.close),
                      ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '${students.length} student${students.length == 1 ? '' : 's'}',
                style: const TextStyle(
                  color: Colors.black54,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          Expanded(
            child: students.isEmpty
                ? const EmptyState(
                    icon: Icons.groups_outlined,
                    title: 'No students found',
                    message: 'Registered student profiles will appear here.',
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(18),
                    itemCount: students.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 9),
                    itemBuilder: (context, index) {
                      final student = students[index];
                      final disabled = student.status == UserStatus.disabled;
                      return Card(
                        color: disabled ? Colors.grey.shade100 : null,
                        child: ListTile(
                          contentPadding: const EdgeInsets.fromLTRB(
                            14,
                            8,
                            8,
                            8,
                          ),
                          leading: UserPhoto(
                            photoBytes: student.photoBytes,
                            radius: 28,
                          ),
                          title: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  student.fullName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                              if (disabled)
                                const Text(
                                  'DISABLED',
                                  style: TextStyle(
                                    color: Colors.redAccent,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                            ],
                          ),
                          subtitle: Text(student.studentNumber ?? ''),
                          trailing: PopupMenuButton<StudentAction>(
                            tooltip: 'Student options',
                            onSelected: (action) => _runAction(student, action),
                            itemBuilder: (context) => [
                              const PopupMenuItem(
                                value: StudentAction.resetPhone,
                                child: ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: Icon(Icons.phonelink_erase),
                                  title: Text('Reset Phone'),
                                ),
                              ),
                              PopupMenuItem(
                                value: StudentAction.toggleDisabled,
                                child: ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: Icon(
                                    disabled
                                        ? Icons.check_circle_outline
                                        : Icons.block,
                                  ),
                                  title: Text(disabled ? 'Enable' : 'Disable'),
                                ),
                              ),
                              const PopupMenuItem(
                                value: StudentAction.delete,
                                child: ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: Icon(
                                    Icons.delete_outline,
                                    color: Colors.red,
                                  ),
                                  title: Text(
                                    'Delete',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      );
    },
  );
}
