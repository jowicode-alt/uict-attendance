import 'package:flutter/material.dart';

import '../models/attendance_models.dart';
import '../services/attendance_service.dart';
import '../widgets/common.dart';

class AdminSettingsPage extends StatefulWidget {
  const AdminSettingsPage({super.key});

  @override
  State<AdminSettingsPage> createState() => _AdminSettingsPageState();
}

class _AdminSettingsPageState extends State<AdminSettingsPage> {
  final _wifi = TextEditingController();
  final _campusName = TextEditingController();
  final _latitude = TextEditingController();
  final _longitude = TextEditingController();
  double _radius = 100;
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final settings = await AttendanceService.instance.loadSettings();
      _apply(settings);
    } catch (error) {
      if (mounted) showMessage(context, error.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _apply(AttendanceSettings settings) {
    _wifi.text = settings.allowedWifiSsids.join(', ');
    _campusName.text = settings.campusName;
    _latitude.text = settings.campusLocation?.latitude.toStringAsFixed(7) ?? '';
    _longitude.text =
        settings.campusLocation?.longitude.toStringAsFixed(7) ?? '';
    _radius = settings.radiusMeters.clamp(25, 1000).toDouble();
  }

  @override
  void dispose() {
    _wifi.dispose();
    _campusName.dispose();
    _latitude.dispose();
    _longitude.dispose();
    super.dispose();
  }

  Future<void> _useCurrentLocation() async {
    setState(() => _busy = true);
    try {
      final position = await AttendanceService.instance.currentPosition();
      _latitude.text = position.latitude.toStringAsFixed(7);
      _longitude.text = position.longitude.toStringAsFixed(7);
      if (mounted) showMessage(context, 'Current campus location captured.');
    } catch (error) {
      if (mounted) {
        final message = error is AttendanceException
            ? error.message
            : error.toString();
        showMessage(context, message, error: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    final latitude = double.tryParse(_latitude.text.trim());
    final longitude = double.tryParse(_longitude.text.trim());
    if (_wifi.text.trim().isEmpty || latitude == null || longitude == null) {
      showMessage(
        context,
        'Enter Wi-Fi names and capture or enter valid campus coordinates.',
        error: true,
      );
      return;
    }
    setState(() => _busy = true);
    try {
      await AttendanceService.instance.saveSettings(
        wifiSsids: _wifi.text.split(','),
        campusName: _campusName.text,
        latitude: latitude,
        longitude: longitude,
        radiusMeters: _radius,
      );
      if (mounted) showMessage(context, 'Attendance settings saved.');
    } catch (error) {
      if (mounted) {
        final message = error is AttendanceException
            ? error.message
            : error.toString();
        showMessage(context, message, error: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Attendance Settings')),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Card(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  child: const Padding(
                    padding: EdgeInsets.all(16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.security_outlined),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Students must match both an approved Wi-Fi name and the GPS radius below. Wi-Fi names are case-sensitive.',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: _wifi,
                  decoration: const InputDecoration(
                    labelText: 'Approved classroom Wi-Fi names',
                    hintText: 'UICT-Classroom, UICT-Lab',
                    helperText: 'Separate multiple names with commas.',
                    prefixIcon: Icon(Icons.wifi),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _campusName,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: 'Campus or classroom label',
                    prefixIcon: Icon(Icons.business_outlined),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _latitude,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                          signed: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Latitude',
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _longitude,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                          signed: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Longitude',
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                  ),
                  onPressed: _busy ? null : _useCurrentLocation,
                  icon: const Icon(Icons.my_location),
                  label: const Text('Use This Phone’s Current Location'),
                ),
                const SizedBox(height: 22),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Attendance radius: ${_radius.round()} metres',
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        Slider(
                          value: _radius,
                          min: 25,
                          max: 1000,
                          divisions: 39,
                          label: '${_radius.round()} m',
                          onChanged: _busy
                              ? null
                              : (value) => setState(() => _radius = value),
                        ),
                        const Text(
                          'Recommended classroom default: 100 metres.',
                          style: TextStyle(color: Colors.black54, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: _busy ? null : _save,
                  icon: _busy
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.save_outlined),
                  label: const Text('Save Attendance Settings'),
                ),
                const BuiltByFooter(),
              ],
            ),
          ),
  );
}
