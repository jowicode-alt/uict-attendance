import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/app_user.dart';
import '../models/attendance_models.dart';
import '../services/attendance_service.dart';
import '../services/auth_service.dart';
import '../services/report_service.dart';
import '../widgets/common.dart';
import 'mark_attendance_page.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key, required this.user});
  final AppUser user;

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      StudentHome(user: widget.user),
      StudentHistory(user: widget.user),
      StudentProfile(user: widget.user),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(
          ['Student Dashboard', 'Attendance History', 'My Profile'][_index],
        ),
      ),
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class StudentHome extends StatelessWidget {
  const StudentHome({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) => StreamBuilder<List<AttendanceRecord>>(
    stream: AttendanceService.instance.studentRecords(user.uid),
    builder: (context, snapshot) {
      final records = snapshot.data ?? const <AttendanceRecord>[];
      final summary = ReportService.instance.summarize(records);
      return RefreshIndicator(
        onRefresh: () async =>
            Future<void>.delayed(const Duration(milliseconds: 500)),
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              color: Theme.of(context).colorScheme.primary,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    UserPhoto(photoBytes: user.photoBytes, radius: 38),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.fullName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 19,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            user.studentNumber ?? '',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.verified_user_outlined,
                      color: Colors.white70,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: SummaryCard(
                    label: 'Present',
                    value: '${summary.present}',
                    icon: Icons.check_circle_outline,
                    color: Colors.green,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SummaryCard(
                    label: 'Absent',
                    value: '${summary.absent}',
                    icon: Icons.cancel_outlined,
                    color: Colors.redAccent,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SummaryCard(
                    label: 'Rate',
                    value: '${summary.percentage.toStringAsFixed(0)}%',
                    icon: Icons.percent,
                    color: Theme.of(context).colorScheme.secondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MarkAttendancePage(student: user),
                ),
              ),
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Mark Attendance'),
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Before marking attendance',
                      style: Theme.of(context).textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 14),
                    const RequirementRow(
                      icon: Icons.wifi,
                      text: 'Connect to the approved classroom Wi-Fi',
                    ),
                    const RequirementRow(
                      icon: Icons.location_on_outlined,
                      text: 'Turn on location and remain inside the approved area',
                    ),
                    const RequirementRow(
                      icon: Icons.phone_android,
                      text: 'Use the phone registered to your account',
                    ),
                    const RequirementRow(
                      icon: Icons.qr_code_2,
                      text: 'Scan the live QR or enter the code shown by the administrator',
                    ),
                  ],
                ),
              ),
            ),
            const BuiltByFooter(),
          ],
        ),
      );
    },
  );
}

class SummaryCard extends StatelessWidget {
  const SummaryCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
      child: Column(
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 6),
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge
                ?.copyWith(fontWeight: FontWeight.w900),
          ),
          Text(
            label,
            style: const TextStyle(color: Colors.black54, fontSize: 12),
          ),
        ],
      ),
    ),
  );
}

class RequirementRow extends StatelessWidget {
  const RequirementRow({super.key, required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 21, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 12),
        Expanded(child: Text(text)),
      ],
    ),
  );
}

class StudentHistory extends StatelessWidget {
  const StudentHistory({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) => StreamBuilder<List<AttendanceRecord>>(
    stream: AttendanceService.instance.studentRecords(user.uid),
    builder: (context, snapshot) {
      if (!snapshot.hasData) {
        return const Center(child: CircularProgressIndicator());
      }
      final records = snapshot.data!;
      if (records.isEmpty) {
        return const EmptyState(
          icon: Icons.event_note_outlined,
          title: 'No attendance history yet',
          message: 'Your completed attendance sessions will appear here.',
        );
      }
      return ListView.separated(
        padding: const EdgeInsets.all(18),
        itemCount: records.length,
        separatorBuilder: (_, _) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final record = records[index];
          final present = record.isPresent;
          return Card(
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 7,
              ),
              leading: CircleAvatar(
                backgroundColor: present
                    ? Colors.green.withValues(alpha: .12)
                    : Colors.red.withValues(alpha: .12),
                child: Icon(
                  present ? Icons.check : Icons.close,
                  color: present ? Colors.green : Colors.red,
                ),
              ),
              title: Text(
                record.sessionTitle,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text(
                record.checkedAt == null
                    ? 'Time pending'
                    : DateFormat('dd MMM yyyy, HH:mm')
                          .format(record.checkedAt!),
              ),
              trailing: Text(
                record.status.toUpperCase(),
                style: TextStyle(
                  color: present ? Colors.green.shade700 : Colors.red.shade700,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
              ),
            ),
          );
        },
      );
    },
  );
}

class StudentProfile extends StatelessWidget {
  const StudentProfile({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const SizedBox(height: 10),
      UserPhoto(photoBytes: user.photoBytes, radius: 62),
      const SizedBox(height: 14),
      Text(
        user.fullName,
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.titleLarge
            ?.copyWith(fontWeight: FontWeight.w900),
      ),
      Text(
        user.studentNumber ?? '',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.black54),
      ),
      const SizedBox(height: 22),
      Card(
        child: Column(
          children: [
            ListTile(
              leading: const Icon(Icons.email_outlined),
              title: const Text('Email'),
              subtitle: Text(user.email),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.phone_outlined),
              title: const Text('Phone'),
              subtitle: Text(user.phone),
            ),
            const Divider(height: 1),
            const ListTile(
              leading: Icon(Icons.phonelink_lock_outlined),
              title: Text('Registered phone'),
              subtitle: Text(
                'To use another phone, ask an administrator to select Reset Phone.',
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 18),
      OutlinedButton.icon(
        style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
        onPressed: AuthService.instance.signOut,
        icon: const Icon(Icons.logout),
        label: const Text('Log out'),
      ),
      const BuiltByFooter(),
    ],
  );
}
