import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../models/app_user.dart';
import '../services/attendance_service.dart';
import '../widgets/common.dart';

class AdminManagementPage extends StatelessWidget {
  const AdminManagementPage({super.key});

  Future<void> _generate(BuildContext context) async {
    try {
      final code = await AttendanceService.instance.generateAdminInvite();
      if (!context.mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          icon: const Icon(Icons.key, size: 48),
          title: const Text('Administrator Code Generated'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Give this code only to the intended administrator. It works once and expires after 24 hours.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 18),
              SelectableText(
                code,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                ),
              ),
            ],
          ),
          actions: [
            TextButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: code));
                if (context.mounted) showMessage(context, 'Code copied.');
              },
              icon: const Icon(Icons.copy),
              label: const Text('Copy'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Done'),
            ),
          ],
        ),
      );
    } catch (error) {
      if (context.mounted) showMessage(context, error.toString(), error: true);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Administrator Management')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => _generate(context),
      icon: const Icon(Icons.add),
      label: const Text('Generate Code'),
    ),
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            'Registered administrators',
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          StreamBuilder<List<AppUser>>(
            stream: AttendanceService.instance.administratorsStream(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const LinearProgressIndicator();
              return Card(
                child: Column(
                  children: snapshot.data!
                      .map(
                        (admin) => ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.admin_panel_settings),
                          ),
                          title: Text(
                            admin.fullName,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text(admin.email),
                        ),
                      )
                      .toList(),
                ),
              );
            },
          ),
          const SizedBox(height: 22),
          Text(
            'Pending registration codes',
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: AttendanceService.instance.adminInvitesStream(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const LinearProgressIndicator();
              final now = DateTime.now();
              final pending = snapshot.data!.docs.where((document) {
                final data = document.data();
                final expiry = (data['expiresAt'] as Timestamp?)?.toDate();
                return data['used'] != true &&
                    data['revoked'] != true &&
                    expiry != null &&
                    expiry.isAfter(now);
              }).toList();
              if (pending.isEmpty) {
                return const Card(
                  child: ListTile(
                    leading: Icon(Icons.key_off_outlined),
                    title: Text('No unused codes'),
                    subtitle: Text(
                      'Generate a code when adding an administrator.',
                    ),
                  ),
                );
              }
              return Column(
                children: pending.map((document) {
                  final data = document.data();
                  final expiry = (data['expiresAt'] as Timestamp).toDate();
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 9),
                    child: Card(
                      child: ListTile(
                        leading: const Icon(Icons.key_outlined),
                        title: Text(
                          'Code …${document.id.substring(document.id.length - 8)}',
                        ),
                        subtitle: Text(
                          'Expires ${DateFormat('dd MMM, HH:mm').format(expiry)}',
                        ),
                        trailing: IconButton(
                          tooltip: 'Revoke code',
                          onPressed: () async {
                            final confirmed = await confirmAction(
                              context,
                              title: 'Revoke registration code?',
                              message: 'This unused code will stop working immediately.',
                              confirmLabel: 'Revoke',
                              destructive: true,
                            );
                            if (confirmed) {
                              await AttendanceService.instance
                                  .revokeAdminInvite(document.id);
                            }
                          },
                          icon: const Icon(
                            Icons.block,
                            color: Colors.redAccent,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
          const SizedBox(height: 90),
        ],
      ),
    ),
  );
}
