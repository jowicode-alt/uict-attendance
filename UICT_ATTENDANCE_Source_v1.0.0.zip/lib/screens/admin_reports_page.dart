import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/attendance_models.dart';
import '../services/attendance_service.dart';
import '../services/report_service.dart';
import '../widgets/common.dart';

enum ReportPeriod { today, thisMonth, allHistory, custom }

class AdminReportsPage extends StatefulWidget {
  const AdminReportsPage({super.key});

  @override
  State<AdminReportsPage> createState() => _AdminReportsPageState();
}

class _AdminReportsPageState extends State<AdminReportsPage> {
  ReportPeriod _period = ReportPeriod.thisMonth;
  DateTimeRange? _customRange;
  bool _exporting = false;

  String get _periodLabel => switch (_period) {
    ReportPeriod.today => 'Today',
    ReportPeriod.thisMonth => 'This month',
    ReportPeriod.allHistory => 'All history',
    ReportPeriod.custom =>
      _customRange == null
          ? 'Custom dates'
          : '${DateFormat('dd MMM').format(_customRange!.start)} – ${DateFormat('dd MMM yyyy').format(_customRange!.end)}',
  };

  List<AttendanceRecord> _filter(List<AttendanceRecord> records) {
    final now = DateTime.now();
    DateTime? start;
    DateTime? end;
    switch (_period) {
      case ReportPeriod.today:
        start = DateTime(now.year, now.month, now.day);
        end = start.add(const Duration(days: 1));
      case ReportPeriod.thisMonth:
        start = DateTime(now.year, now.month);
        end = DateTime(now.year, now.month + 1);
      case ReportPeriod.allHistory:
        return records;
      case ReportPeriod.custom:
        if (_customRange == null) return records;
        start = DateTime(
          _customRange!.start.year,
          _customRange!.start.month,
          _customRange!.start.day,
        );
        end = DateTime(
          _customRange!.end.year,
          _customRange!.end.month,
          _customRange!.end.day + 1,
        );
    }
    return records.where((record) {
      final date = record.checkedAt;
      return date != null && !date.isBefore(start!) && date.isBefore(end!);
    }).toList();
  }

  Future<void> _chooseCustomRange() async {
    final now = DateTime.now();
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 1),
      initialDateRange: _customRange,
    );
    if (range != null) {
      setState(() {
        _customRange = range;
        _period = ReportPeriod.custom;
      });
    }
  }

  Future<void> _export(
    List<AttendanceRecord> records,
    Future<void> Function() action,
  ) async {
    if (records.isEmpty) {
      showMessage(
        context,
        'There are no records in this report period.',
        error: true,
      );
      return;
    }
    setState(() => _exporting = true);
    try {
      await action();
    } catch (error) {
      if (mounted) {
        showMessage(context, 'Report export failed: $error', error: true);
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<AttendanceRecord>>(
    stream: AttendanceService.instance.allRecords(),
    builder: (context, snapshot) {
      if (!snapshot.hasData) {
        return const Center(child: CircularProgressIndicator());
      }
      final records = _filter(snapshot.data!);
      final summary = ReportService.instance.summarize(records);
      final groups = <String, List<AttendanceRecord>>{};
      for (final record in records) {
        groups.putIfAbsent(record.studentUid, () => []).add(record);
      }
      final studentSummaries = groups.values.toList()
        ..sort((a, b) => a.first.studentName.compareTo(b.first.studentName));
      final reportTitle = 'UICT Attendance - $_periodLabel';

      return ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<ReportPeriod>(
                  initialValue: _period,
                  decoration: const InputDecoration(
                    labelText: 'Report period',
                    prefixIcon: Icon(Icons.date_range_outlined),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: ReportPeriod.today,
                      child: Text('Today'),
                    ),
                    DropdownMenuItem(
                      value: ReportPeriod.thisMonth,
                      child: Text('This month'),
                    ),
                    DropdownMenuItem(
                      value: ReportPeriod.allHistory,
                      child: Text('All history'),
                    ),
                    DropdownMenuItem(
                      value: ReportPeriod.custom,
                      child: Text('Custom dates'),
                    ),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    if (value == ReportPeriod.custom) {
                      await _chooseCustomRange();
                    } else {
                      setState(() => _period = value);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: 'Choose custom dates',
                onPressed: _chooseCustomRange,
                icon: const Icon(Icons.calendar_month_outlined),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ReportMetric(
                  label: 'Present',
                  value: '${summary.present}',
                  color: Colors.green,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ReportMetric(
                  label: 'Absent',
                  value: '${summary.absent}',
                  color: Colors.redAccent,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ReportMetric(
                  label: 'Rate',
                  value: '${summary.percentage.toStringAsFixed(1)}%',
                  color: Theme.of(context).colorScheme.secondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text('${summary.sessions} sessions'),
                  Text('${summary.students} students'),
                  Text('${summary.totalRecords} records'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'Export report',
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 9),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _exporting
                      ? null
                      : () => _export(
                          records,
                          () => ReportService.instance.sharePdfReport(
                            records: records,
                            title: reportTitle,
                          ),
                        ),
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('PDF'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _exporting
                      ? null
                      : () => _export(
                          records,
                          () => ReportService.instance.shareExcelReport(
                            records: records,
                            title: reportTitle,
                          ),
                        ),
                  icon: const Icon(Icons.table_chart_outlined),
                  label: const Text('Excel'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _exporting
                      ? null
                      : () => _export(
                          records,
                          () => ReportService.instance.shareCsvReport(
                            records: records,
                            title: reportTitle,
                          ),
                        ),
                  icon: const Icon(Icons.data_object),
                  label: const Text('CSV'),
                ),
              ),
            ],
          ),
          if (_exporting) ...[
            const SizedBox(height: 10),
            const LinearProgressIndicator(),
          ],
          const SizedBox(height: 22),
          Text(
            'Student percentages',
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 9),
          if (studentSummaries.isEmpty)
            const Card(
              child: ListTile(
                leading: Icon(Icons.assessment_outlined),
                title: Text('No records for this period'),
              ),
            )
          else
            Card(
              child: Column(
                children: studentSummaries.map((studentRecords) {
                  final studentSummary = ReportService.instance.summarize(
                    studentRecords,
                  );
                  return ListTile(
                    title: Text(
                      studentRecords.first.studentName,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(
                      '${studentRecords.first.studentNumber} • ${studentSummary.present}/${studentSummary.totalRecords} present',
                    ),
                    trailing: Text(
                      '${studentSummary.percentage.toStringAsFixed(1)}%',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: studentSummary.percentage >= 75
                            ? Colors.green.shade700
                            : Colors.red.shade700,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          const SizedBox(height: 22),
          Text(
            'Attendance records',
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 9),
          ...records
              .take(100)
              .map(
                (record) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Card(
                    child: ListTile(
                      leading: Icon(
                        record.isPresent ? Icons.check_circle : Icons.cancel,
                        color: record.isPresent
                            ? Colors.green
                            : Colors.redAccent,
                      ),
                      title: Text(
                        record.studentName,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Text(
                        '${record.studentNumber} • ${record.sessionTitle}\n${record.checkedAt == null ? 'Time pending' : DateFormat('dd MMM yyyy, HH:mm').format(record.checkedAt!)}',
                      ),
                      isThreeLine: true,
                      trailing: Text(
                        record.status.toUpperCase(),
                        style: TextStyle(
                          color: record.isPresent
                              ? Colors.green.shade700
                              : Colors.red.shade700,
                          fontWeight: FontWeight.w800,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          if (records.length > 100)
            Text(
              'Showing the latest 100 of ${records.length} records. Exports include all records.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
          const BuiltByFooter(),
        ],
      );
    },
  );
}

class ReportMetric extends StatelessWidget {
  const ReportMetric({
    super.key,
    required this.label,
    required this.value,
    required this.color,
  });
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 7),
      child: Column(
        children: [
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge
                ?.copyWith(color: color, fontWeight: FontWeight.w900),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    ),
  );
}
