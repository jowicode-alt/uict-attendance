import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/app_user.dart';
import '../models/attendance_models.dart';
import '../services/app_constants.dart';
import '../services/attendance_service.dart';
import '../services/device_service.dart';
import '../widgets/common.dart';

class AdminSessionPage extends StatefulWidget {
  const AdminSessionPage({
    super.key,
    required this.sessionId,
    this.initialCode,
    this.initialQrPayload,
  });

  final String sessionId;
  final String? initialCode;
  final String? initialQrPayload;

  @override
  State<AdminSessionPage> createState() => _AdminSessionPageState();
}

class _AdminSessionPageState extends State<AdminSessionPage> {
  String? _code;
  String? _qrPayload;
  final ValueNotifier<String?> _qrNotifier = ValueNotifier<String?>(null);
  DateTime? _nextRotation;
  Timer? _timer;
  bool _loading = true;
  bool _rotating = false;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      _code =
          widget.initialCode ??
          await DeviceService.instance.readSessionCode(widget.sessionId);
      _code ??= await AttendanceService.instance.regenerateAttendanceCode(
        widget.sessionId,
      );
      if (widget.initialQrPayload != null) {
        _qrPayload = widget.initialQrPayload;
      } else {
        final rotated = await AttendanceService.instance.rotateQr(
          widget.sessionId,
        );
        _qrPayload = rotated.payload;
      }
      _qrNotifier.value = _qrPayload;
      _nextRotation = DateTime.now().add(
        const Duration(seconds: AppConstants.qrRotationSeconds),
      );
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted || _nextRotation == null) return;
        if (DateTime.now().isAfter(_nextRotation!) && !_rotating) {
          _rotateQr();
        } else {
          setState(() {});
        }
      });
    } catch (error) {
      if (mounted) showMessage(context, error.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _qrNotifier.dispose();
    super.dispose();
  }

  int get _secondsRemaining {
    if (_nextRotation == null) return 0;
    return _nextRotation!.difference(DateTime.now()).inSeconds.clamp(0, 30);
  }

  Future<void> _rotateQr() async {
    if (_rotating || _closing) return;
    _rotating = true;
    try {
      final rotated = await AttendanceService.instance.rotateQr(
        widget.sessionId,
      );
      if (mounted) {
        setState(() {
          _qrPayload = rotated.payload;
          _qrNotifier.value = rotated.payload;
          _nextRotation = DateTime.now().add(
            const Duration(seconds: AppConstants.qrRotationSeconds),
          );
        });
      }
    } catch (error) {
      if (mounted) showMessage(context, error.toString(), error: true);
    } finally {
      _rotating = false;
    }
  }

  Future<void> _regenerateCode() async {
    try {
      final code = await AttendanceService.instance.regenerateAttendanceCode(
        widget.sessionId,
      );
      if (mounted) {
        setState(() => _code = code);
        showMessage(context, 'A new attendance code was generated.');
      }
    } catch (error) {
      if (mounted) showMessage(context, error.toString(), error: true);
    }
  }

  Future<void> _closeSession() async {
    final confirmed = await confirmAction(
      context,
      title: 'Close attendance session?',
      message: 'Students who did not mark attendance will be recorded as absent. The displayed QR and code will stop working.',
      confirmLabel: 'Close Session',
      destructive: true,
    );
    if (!confirmed) return;
    setState(() => _closing = true);
    try {
      await AttendanceService.instance.closeSession(widget.sessionId);
      if (mounted) {
        showMessage(context, 'Attendance session closed.');
        Navigator.pop(context);
      }
    } catch (error) {
      if (mounted) showMessage(context, error.toString(), error: true);
      if (mounted) setState(() => _closing = false);
    }
  }

  void _showFullScreenQr() {
    if (_qrPayload == null) return;
    showDialog<void>(
      context: context,
      builder: (context) => Dialog.fullscreen(
        child: SafeArea(
          child: Column(
            children: [
              AppBar(
                title: const Text('Scan to Mark Attendance'),
                leading: IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ),
              Expanded(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: ValueListenableBuilder<String?>(
                      valueListenable: _qrNotifier,
                      builder: (context, payload, _) => payload == null
                          ? const CircularProgressIndicator()
                          : QrImageView(
                              data: payload,
                              size: 340,
                              backgroundColor: Colors.white,
                              eyeStyle: const QrEyeStyle(
                                eyeShape: QrEyeShape.square,
                                color: Color(0xFF0B1F3A),
                              ),
                              dataModuleStyle: const QrDataModuleStyle(
                                dataModuleShape: QrDataModuleShape.square,
                                color: Color(0xFF0B1F3A),
                              ),
                            ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(28),
                child: Text(
                  'Backup code: ${_code ?? 'Generating…'}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 22,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<AttendanceSession?>(
    stream: AttendanceService.instance.sessionStream(widget.sessionId),
    builder: (context, sessionSnapshot) {
      final session = sessionSnapshot.data;
      final closed = session != null && !session.isOpen;
      return Scaffold(
        appBar: AppBar(
          title: Text(session?.title ?? 'Attendance Session'),
          actions: [
            IconButton(
              tooltip: 'Refresh QR now',
              onPressed: _loading || closed ? null : _rotateQr,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : closed
            ? const EmptyState(
                icon: Icons.event_busy,
                title: 'This session is closed',
                message: 'Its QR and attendance code are no longer valid.',
              )
            : SafeArea(
                child: ListView(
                  padding: const EdgeInsets.all(18),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          children: [
                            const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.circle,
                                  color: Colors.green,
                                  size: 13,
                                ),
                                SizedBox(width: 8),
                                Text(
                                  'ATTENDANCE OPEN',
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            InkWell(
                              onTap: _showFullScreenQr,
                              child: Container(
                                color: Colors.white,
                                padding: const EdgeInsets.all(10),
                                child: _qrPayload == null
                                    ? const SizedBox.square(
                                        dimension: 230,
                                        child: Center(
                                          child: CircularProgressIndicator(),
                                        ),
                                      )
                                    : QrImageView(
                                        data: _qrPayload!,
                                        size: 230,
                                        backgroundColor: Colors.white,
                                      ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _rotating
                                  ? 'Refreshing secure QR…'
                                  : 'QR refreshes in $_secondsRemaining seconds',
                              style: const TextStyle(color: Colors.black54),
                            ),
                            const SizedBox(height: 18),
                            const Text(
                              'BACKUP CODE',
                              style: TextStyle(
                                color: Colors.black54,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.4,
                              ),
                            ),
                            const SizedBox(height: 5),
                            SelectableText(
                              _code ?? '------',
                              style: const TextStyle(
                                fontSize: 34,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 8,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TextButton.icon(
                                  onPressed: _code == null
                                      ? null
                                      : () async {
                                          await Clipboard.setData(
                                            ClipboardData(text: _code!),
                                          );
                                          if (!context.mounted) return;
                                          showMessage(context, 'Code copied.');
                                        },
                                  icon: const Icon(Icons.copy, size: 18),
                                  label: const Text('Copy'),
                                ),
                                TextButton.icon(
                                  onPressed: _regenerateCode,
                                  icon: const Icon(Icons.autorenew, size: 18),
                                  label: const Text('New Code'),
                                ),
                              ],
                            ),
                            const Text(
                              'Students scan this screen or enter the backup code. Do not send it remotely.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Live attendance',
                      style: Theme.of(context).textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 9),
                    StreamBuilder<List<AppUser>>(
                      stream: AttendanceService.instance.studentsStream(),
                      builder: (context, studentsSnapshot) {
                        final photoByStudentUid = {
                          for (final student
                              in studentsSnapshot.data ?? const <AppUser>[])
                            student.uid: student.photoBytes,
                        };
                        return StreamBuilder<List<AttendanceRecord>>(
                          stream: AttendanceService.instance.sessionRecords(
                            widget.sessionId,
                          ),
                          builder: (context, snapshot) {
                            if (!snapshot.hasData) {
                              return const LinearProgressIndicator();
                            }
                            final records = snapshot.data!
                                .where((record) => record.isPresent)
                                .toList();
                            if (records.isEmpty) {
                              return const Card(
                                child: ListTile(
                                  leading: Icon(Icons.hourglass_empty),
                                  title: Text('Waiting for students'),
                                  subtitle: Text(
                                    'Verified check-ins will appear here immediately.',
                                  ),
                                ),
                              );
                            }
                            return Card(
                              child: Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(14),
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        '${records.length} present',
                                        style: const TextStyle(
                                          color: Colors.green,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const Divider(height: 1),
                                  ...records.map(
                                    (record) => ListTile(
                                      leading: UserPhoto(
                                        photoBytes:
                                            photoByStudentUid[record
                                                .studentUid],
                                        radius: 23,
                                      ),
                                      title: Text(
                                        record.studentName,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      subtitle: Text(record.studentNumber),
                                      trailing: const Icon(
                                        Icons.check_circle,
                                        color: Colors.green,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.red.shade700,
                      ),
                      onPressed: _closing ? null : _closeSession,
                      icon: _closing
                          ? const SizedBox.square(
                              dimension: 18,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.stop_circle_outlined),
                      label: const Text('Close Attendance Session'),
                    ),
                    const SizedBox(height: 18),
                  ],
                ),
              ),
      );
    },
  );
}
