import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

class DeviceService {
  DeviceService._();

  static final DeviceService instance = DeviceService._();
  static const _deviceIdKey = 'uict_registered_device_id';
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(storageNamespace: 'uict_attendance'),
  );

  Future<String> getDeviceId() async {
    final existing = await _storage.read(key: _deviceIdKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final created = const Uuid().v4();
    await _storage.write(key: _deviceIdKey, value: created);
    return created;
  }

  Future<void> saveSessionCode(String sessionId, String code) =>
      _storage.write(key: 'attendance_code_$sessionId', value: code);

  Future<String?> readSessionCode(String sessionId) =>
      _storage.read(key: 'attendance_code_$sessionId');

  Future<void> clearSessionCode(String sessionId) =>
      _storage.delete(key: 'attendance_code_$sessionId');
}
