class AppConstants {
  const AppConstants._();

  static const appName = 'UICT ATTENDANCE';
  static const organization = 'UICT BBIT';
  static const builtBy = 'WIZZARD NATION';

  // SHA-256 only. The matching one-time bootstrap code is delivered separately
  // in the private client handover document and is never stored in the app.
  static const firstAdminCodeHash =
      '48bf349ea8e14b44f2270faa3f9fd1720a274dd7cfc3160f173d51eff956530d';

  static const qrPrefix = 'UICTATTENDANCE';
  static const qrRotationSeconds = 30;
  static const qrGraceSeconds = 45;
}
