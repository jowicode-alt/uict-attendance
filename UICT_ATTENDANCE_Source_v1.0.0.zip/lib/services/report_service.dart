import 'dart:io';

import 'package:csv/csv.dart';
import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../models/attendance_models.dart';
import 'app_constants.dart';

class AttendanceSummary {
  const AttendanceSummary({
    required this.totalRecords,
    required this.present,
    required this.absent,
    required this.sessions,
    required this.students,
  });

  final int totalRecords;
  final int present;
  final int absent;
  final int sessions;
  final int students;

  double get percentage => totalRecords == 0 ? 0 : present * 100 / totalRecords;
}

class ReportService {
  ReportService._();

  static final ReportService instance = ReportService._();
  final DateFormat _dateTime = DateFormat('dd MMM yyyy, HH:mm');

  AttendanceSummary summarize(List<AttendanceRecord> records) {
    final present = records.where((record) => record.isPresent).length;
    return AttendanceSummary(
      totalRecords: records.length,
      present: present,
      absent: records.length - present,
      sessions: records.map((record) => record.sessionId).toSet().length,
      students: records.map((record) => record.studentUid).toSet().length,
    );
  }

  List<List<dynamic>> _rows(List<AttendanceRecord> records) => [
    ['Student name', 'Student number', 'Session', 'Status', 'Date and time'],
    ...records.map(
      (record) => [
        record.studentName,
        record.studentNumber,
        record.sessionTitle,
        record.status.toUpperCase(),
        record.checkedAt == null ? '' : _dateTime.format(record.checkedAt!),
      ],
    ),
  ];

  String _safeName(String title) => title
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_|_$'), '');

  Future<void> sharePdfReport({
    required List<AttendanceRecord> records,
    required String title,
  }) async {
    final summary = summarize(records);
    final document = pw.Document(
      title: '$title - ${AppConstants.appName}',
      author: AppConstants.builtBy,
    );
    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(28),
        header: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(
              AppConstants.appName,
              style: pw.TextStyle(
                fontSize: 18,
                fontWeight: pw.FontWeight.bold,
                color: PdfColor.fromHex('#0B1F3A'),
              ),
            ),
            pw.SizedBox(height: 4),
            pw.Text(title, style: const pw.TextStyle(fontSize: 13)),
            pw.Divider(color: PdfColor.fromHex('#D5A72E')),
          ],
        ),
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text(
            'Page ${context.pageNumber} of ${context.pagesCount} • ${AppConstants.builtBy}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
          ),
        ),
        build: (context) => [
          pw.Wrap(
            spacing: 24,
            runSpacing: 8,
            children: [
              pw.Text('Sessions: ${summary.sessions}'),
              pw.Text('Students: ${summary.students}'),
              pw.Text('Present: ${summary.present}'),
              pw.Text('Absent: ${summary.absent}'),
              pw.Text('Attendance: ${summary.percentage.toStringAsFixed(1)}%'),
            ],
          ),
          pw.SizedBox(height: 16),
          pw.TableHelper.fromTextArray(
            headers: const [
              'Student name',
              'Student number',
              'Session',
              'Status',
              'Date and time',
            ],
            data: records
                .map(
                  (record) => [
                    record.studentName,
                    record.studentNumber,
                    record.sessionTitle,
                    record.status.toUpperCase(),
                    record.checkedAt == null
                        ? ''
                        : _dateTime.format(record.checkedAt!),
                  ],
                )
                .toList(),
            headerDecoration: pw.BoxDecoration(
              color: PdfColor.fromHex('#0B1F3A'),
            ),
            headerStyle: pw.TextStyle(
              color: PdfColors.white,
              fontWeight: pw.FontWeight.bold,
              fontSize: 9,
            ),
            cellStyle: const pw.TextStyle(fontSize: 8),
            cellPadding: const pw.EdgeInsets.all(5),
            rowDecoration: const pw.BoxDecoration(
              border: pw.Border(
                bottom: pw.BorderSide(color: PdfColors.grey300, width: .5),
              ),
            ),
          ),
        ],
      ),
    );
    await Printing.sharePdf(
      bytes: await document.save(),
      filename: '${_safeName(title)}.pdf',
    );
  }

  Future<void> shareCsvReport({
    required List<AttendanceRecord> records,
    required String title,
  }) async {
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/${_safeName(title)}.csv');
    await file.writeAsString(Csv(addBom: true).encode(_rows(records)));
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(file.path)],
        subject: '$title - ${AppConstants.appName}',
      ),
    );
  }

  Future<void> shareExcelReport({
    required List<AttendanceRecord> records,
    required String title,
  }) async {
    final excel = Excel.createExcel();
    final sheet = excel['Attendance'];
    for (final row in _rows(records)) {
      sheet.appendRow(
        row.map((value) => TextCellValue(value.toString())).toList(),
      );
    }
    if (excel.tables.containsKey('Sheet1')) excel.delete('Sheet1');
    final bytes = excel.encode();
    if (bytes == null) throw StateError('Could not create the Excel report.');
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/${_safeName(title)}.xlsx');
    await file.writeAsBytes(bytes, flush: true);
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(file.path)],
        subject: '$title - ${AppConstants.appName}',
      ),
    );
  }
}
