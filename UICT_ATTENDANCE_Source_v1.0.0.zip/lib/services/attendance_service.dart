import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:uuid/uuid.dart';

import '../models/app_user.dart';
import '../models/attendance_models.dart';
import 'app_constants.dart';
import 'auth_service.dart';
import 'device_service.dart';

class AttendanceException implements Exception {
  const AttendanceException(this.message);
  final String message;

  @override
  String toString() => message;
}

class OpenSessionResult {
  const OpenSessionResult({
    required this.sessionId,
    required this.code,
    required this.qrPayload,
  });

  final String sessionId;
  final String code;
  final String qrPayload;
}

class RotatedQr {
  const RotatedQr({required this.payload, required this.expiresAt});
  final String payload;
  final DateTime expiresAt;
}

class AttendanceService {
  AttendanceService._();

  static final AttendanceService instance = AttendanceService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final NetworkInfo _networkInfo = NetworkInfo();
  final Random _random = Random.secure();

  String _randomCharacters(int length, {bool digitsOnly = false}) {
    const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const digits = '23456789';
    final source = digitsOnly ? digits : letters;
    return List.generate(
      length,
      (_) => source[_random.nextInt(source.length)],
    ).join();
  }

  String _newAttendanceCode() => _randomCharacters(6);

  String _newAdminCode() {
    final raw = _randomCharacters(12);
    return 'UICT-ADM-${raw.substring(0, 4)}-${raw.substring(4, 8)}-${raw.substring(8)}';
  }

  String _newQrToken() => '${const Uuid().v4()}-${_randomCharacters(12)}';

  Stream<AttendanceSettings> settingsStream() => _db
      .collection('settings')
      .doc('attendance')
      .snapshots()
      .map(AttendanceSettings.fromDocument);

  Future<AttendanceSettings> loadSettings() async =>
      AttendanceSettings.fromDocument(
        await _db.collection('settings').doc('attendance').get(),
      );

  Future<void> saveSettings({
    required List<String> wifiSsids,
    required String campusName,
    required double latitude,
    required double longitude,
    required double radiusMeters,
  }) async {
    final cleaned = wifiSsids
        .map((value) => value.trim().replaceAll('"', ''))
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList();
    if (cleaned.isEmpty) {
      throw const AttendanceException('Add at least one classroom Wi-Fi name.');
    }
    await _db.collection('settings').doc('attendance').set({
      'allowedWifiSsids': cleaned,
      'campusName': campusName.trim().isEmpty
          ? 'UICT BBIT Classroom'
          : campusName.trim(),
      'campusLocation': GeoPoint(latitude, longitude),
      'radiusMeters': radiusMeters,
      'updatedBy': _auth.currentUser!.uid,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<Position> currentPosition() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw const AttendanceException(
        'Turn on Location Services before continuing.',
      );
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const AttendanceException(
        'Location permission is required to confirm classroom attendance.',
      );
    }
    if (permission == LocationPermission.deniedForever) {
      throw const AttendanceException(
        'Location permission is blocked. Enable it in the phone settings.',
      );
    }
    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 20),
      ),
    );
  }

  Stream<List<AttendanceSession>> sessionsStream() => _db
      .collection('sessions')
      .orderBy('openedAt', descending: true)
      .limit(100)
      .snapshots()
      .map(
        (snapshot) =>
            snapshot.docs.map(AttendanceSession.fromDocument).toList(),
      );

  Stream<AttendanceSession?> sessionStream(String sessionId) => _db
      .collection('sessions')
      .doc(sessionId)
      .snapshots()
      .map(
        (document) =>
            document.exists ? AttendanceSession.fromDocument(document) : null,
      );

  Future<OpenSessionResult> openSession(String title) async {
    final active = await _db
        .collection('sessions')
        .where('status', isEqualTo: 'open')
        .limit(1)
        .get();
    if (active.docs.isNotEmpty) {
      throw const AttendanceException(
        'Close the current attendance session before opening another.',
      );
    }
    final settings = await loadSettings();
    if (!settings.isConfigured) {
      throw const AttendanceException(
        'Configure classroom Wi-Fi and GPS settings before opening attendance.',
      );
    }

    final sessionRef = _db.collection('sessions').doc();
    final attendanceStateRef = _db.collection('system').doc('attendanceState');
    final code = _newAttendanceCode();
    final codeHash = AuthService.hashValue(code);
    final qrToken = _newQrToken();
    final qrHash = AuthService.hashValue(qrToken);
    final qrExpires = DateTime.now().add(
      const Duration(seconds: AppConstants.qrGraceSeconds),
    );
    final codeProof = _db.collection('attendanceProofs').doc(codeHash);
    final qrProof = _db.collection('attendanceProofs').doc(qrHash);
    await _db.runTransaction((transaction) async {
      final attendanceState = await transaction.get(attendanceStateRef);
      final activeSessionId =
          attendanceState.data()?['activeSessionId'] as String?;
      if (activeSessionId != null && activeSessionId.isNotEmpty) {
        final lockedSession = await transaction.get(
          _db.collection('sessions').doc(activeSessionId),
        );
        if (lockedSession.data()?['status'] == 'open') {
          throw const AttendanceException(
            'Another administrator already has an open attendance session.',
          );
        }
      }

      transaction.set(sessionRef, {
        'title': title.trim(),
        'status': 'open',
        'openedBy': _auth.currentUser!.uid,
        'openedAt': FieldValue.serverTimestamp(),
        'codeHash': codeHash,
        'currentQrHash': qrHash,
      });
      transaction.set(codeProof, {
        'sessionId': sessionRef.id,
        'sessionTitle': title.trim(),
        'type': 'code',
        'active': true,
        'createdAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(
          DateTime.now().add(const Duration(hours: 24)),
        ),
      });
      transaction.set(qrProof, {
        'sessionId': sessionRef.id,
        'sessionTitle': title.trim(),
        'type': 'qr',
        'active': true,
        'createdAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(qrExpires),
      });
      transaction.set(attendanceStateRef, {
        'activeSessionId': sessionRef.id,
        'acceptingCheckIns': true,
        'updatedBy': _auth.currentUser!.uid,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
    await DeviceService.instance.saveSessionCode(sessionRef.id, code);
    return OpenSessionResult(
      sessionId: sessionRef.id,
      code: code,
      qrPayload: '${AppConstants.qrPrefix}|$qrToken',
    );
  }

  Future<RotatedQr> rotateQr(String sessionId) async {
    final sessionRef = _db.collection('sessions').doc(sessionId);
    final document = await sessionRef.get();
    final data = document.data();
    if (!document.exists || data?['status'] != 'open') {
      throw const AttendanceException('This attendance session is closed.');
    }
    final title = data?['title'] as String? ?? 'Attendance session';
    final token = _newQrToken();
    final hash = AuthService.hashValue(token);
    final expiresAt = DateTime.now().add(
      const Duration(seconds: AppConstants.qrGraceSeconds),
    );
    final batch = _db.batch();
    batch.set(_db.collection('attendanceProofs').doc(hash), {
      'sessionId': sessionId,
      'sessionTitle': title,
      'type': 'qr',
      'active': true,
      'createdAt': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(expiresAt),
    });
    batch.update(sessionRef, {'currentQrHash': hash});
    // The previous QR proof remains valid only until its short expiry. This
    // grace avoids rejecting a student whose scan overlaps a refresh.
    await batch.commit();
    return RotatedQr(
      payload: '${AppConstants.qrPrefix}|$token',
      expiresAt: expiresAt,
    );
  }

  Future<String> regenerateAttendanceCode(String sessionId) async {
    final sessionRef = _db.collection('sessions').doc(sessionId);
    final document = await sessionRef.get();
    final data = document.data();
    if (!document.exists || data?['status'] != 'open') {
      throw const AttendanceException('This attendance session is closed.');
    }
    final oldHash = data?['codeHash'] as String?;
    final code = _newAttendanceCode();
    final hash = AuthService.hashValue(code);
    final batch = _db.batch();
    batch.set(_db.collection('attendanceProofs').doc(hash), {
      'sessionId': sessionId,
      'sessionTitle': data?['title'] as String? ?? 'Attendance session',
      'type': 'code',
      'active': true,
      'createdAt': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(
        DateTime.now().add(const Duration(hours: 24)),
      ),
    });
    batch.update(sessionRef, {'codeHash': hash});
    if (oldHash != null && oldHash.isNotEmpty) {
      batch.update(_db.collection('attendanceProofs').doc(oldHash), {
        'active': false,
      });
    }
    await batch.commit();
    await DeviceService.instance.saveSessionCode(sessionId, code);
    return code;
  }

  Future<void> closeSession(String sessionId) async {
    final sessionRef = _db.collection('sessions').doc(sessionId);
    final sessionDocument = await sessionRef.get();
    final session = sessionDocument.data();
    if (!sessionDocument.exists || session?['status'] != 'open') return;

    // Lock check-ins first. Firestore evaluates student writes against this
    // server-side state, so a check-in cannot race the absent-record pass.
    final lockBatch = _db.batch();
    lockBatch.set(_db.collection('system').doc('attendanceState'), {
      'activeSessionId': null,
      'acceptingCheckIns': false,
      'lastSessionId': sessionId,
      'updatedBy': _auth.currentUser!.uid,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    for (final hash in [
      session?['codeHash'] as String?,
      session?['currentQrHash'] as String?,
    ]) {
      if (hash != null && hash.isNotEmpty) {
        lockBatch.update(_db.collection('attendanceProofs').doc(hash), {
          'active': false,
        });
      }
    }
    await lockBatch.commit();

    final students = await _db
        .collection('users')
        .where('role', isEqualTo: 'student')
        .get();
    final recordsRef = sessionRef.collection('records');
    final existing = await recordsRef.get();
    final marked = existing.docs.map((doc) => doc.id).toSet();
    final openedAt = (session?['openedAt'] as Timestamp?)?.toDate();
    final activeStudents = students.docs.where((document) {
      final data = document.data();
      final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
      return data['status'] == 'active' &&
          (openedAt == null ||
              createdAt == null ||
              !createdAt.isAfter(openedAt));
    }).toList();

    for (var start = 0; start < activeStudents.length; start += 400) {
      final batch = _db.batch();
      final end = min(start + 400, activeStudents.length);
      for (final student in activeStudents.sublist(start, end)) {
        if (marked.contains(student.id)) continue;
        final data = student.data();
        batch.set(recordsRef.doc(student.id), {
          'sessionId': sessionId,
          'sessionTitle': session?['title'] as String? ?? 'Attendance session',
          'studentUid': student.id,
          'studentName': data['fullName'] as String? ?? 'Unknown student',
          'studentNumber': data['studentNumber'] as String? ?? '',
          'status': 'absent',
          'proofType': 'session_close',
          'checkedAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();
    }

    await sessionRef.update({
      'status': 'closed',
      'closedBy': _auth.currentUser!.uid,
      'closedAt': FieldValue.serverTimestamp(),
      'attendanceFinalized': true,
    });
    await DeviceService.instance.clearSessionCode(sessionId);
  }

  Future<void> markWithCode({required String code, required AppUser student}) =>
      _markWithProof(
        proofHash: AuthService.hashValue(code.trim().toUpperCase()),
        student: student,
      );

  Future<void> markWithQr({
    required String payload,
    required AppUser student,
  }) async {
    final parts = payload.trim().split('|');
    if (parts.length != 2 || parts.first != AppConstants.qrPrefix) {
      throw const AttendanceException('This is not a UICT attendance QR code.');
    }
    await _markWithProof(
      proofHash: AuthService.hashValue(parts[1]),
      student: student,
    );
  }

  Future<void> _markWithProof({
    required String proofHash,
    required AppUser student,
  }) async {
    final proof = await _db.collection('attendanceProofs').doc(proofHash).get();
    final proofData = proof.data();
    final expiry = proofData?['expiresAt'] as Timestamp?;
    if (!proof.exists ||
        proofData?['active'] != true ||
        expiry == null ||
        expiry.toDate().isBefore(DateTime.now())) {
      throw const AttendanceException(
        'That attendance QR or code is invalid or expired.',
      );
    }
    final sessionId = proofData?['sessionId'] as String? ?? '';
    if (sessionId.isEmpty) {
      throw const AttendanceException('The attendance session is invalid.');
    }

    final settings = await loadSettings();
    if (!settings.isConfigured) {
      throw const AttendanceException(
        'Attendance location has not been configured by an administrator.',
      );
    }
    final deviceId = await DeviceService.instance.getDeviceId();
    if (student.deviceId != deviceId) {
      throw const AttendanceException(
        'This is not the phone registered to your student account. Ask an administrator to reset it.',
      );
    }

    // Android and iOS expose the Wi-Fi name only after location permission is
    // granted, so resolve permission and position before reading the SSID.
    final position = await currentPosition();
    final wifiName = (await _networkInfo.getWifiName())
        ?.replaceAll('"', '')
        .trim();
    if (wifiName == null || wifiName.isEmpty) {
      throw const AttendanceException(
        'Connect to the approved classroom Wi-Fi and allow location permission.',
      );
    }
    if (!settings.allowedWifiSsids.contains(wifiName)) {
      throw AttendanceException(
        'You are connected to “$wifiName”, not an approved classroom Wi-Fi.',
      );
    }

    final campus = settings.campusLocation!;
    final distance = Geolocator.distanceBetween(
      position.latitude,
      position.longitude,
      campus.latitude,
      campus.longitude,
    );
    if (distance > settings.radiusMeters) {
      throw AttendanceException(
        'You are ${distance.round()} m from the approved classroom area. Move inside the ${settings.radiusMeters.round()} m attendance radius.',
      );
    }

    final recordRef = _db
        .collection('sessions')
        .doc(sessionId)
        .collection('records')
        .doc(student.uid);
    if ((await recordRef.get()).exists) {
      throw const AttendanceException(
        'Your attendance is already recorded for this session.',
      );
    }
    await recordRef.set({
      'sessionId': sessionId,
      'sessionTitle':
          proofData?['sessionTitle'] as String? ?? 'Attendance session',
      'studentUid': student.uid,
      'studentName': student.fullName,
      'studentNumber': student.studentNumber ?? '',
      'status': 'present',
      'proofType': proofData?['type'] as String? ?? 'code',
      'proofHash': proofHash,
      'deviceId': deviceId,
      'wifiSsid': wifiName,
      'location': GeoPoint(position.latitude, position.longitude),
      'accuracyMeters': position.accuracy,
      'checkedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<List<AttendanceRecord>> studentRecords(String uid) => _db
      .collectionGroup('records')
      .where('studentUid', isEqualTo: uid)
      .snapshots()
      .map((snapshot) {
        final records = snapshot.docs
            .map(AttendanceRecord.fromDocument)
            .toList();
        records.sort(
          (a, b) => (b.checkedAt ?? DateTime(1970)).compareTo(
            a.checkedAt ?? DateTime(1970),
          ),
        );
        return records;
      });

  Stream<List<AttendanceRecord>> allRecords() =>
      _db.collectionGroup('records').snapshots().map((snapshot) {
        final records = snapshot.docs
            .map(AttendanceRecord.fromDocument)
            .toList();
        records.sort(
          (a, b) => (b.checkedAt ?? DateTime(1970)).compareTo(
            a.checkedAt ?? DateTime(1970),
          ),
        );
        return records;
      });

  Stream<List<AttendanceRecord>> sessionRecords(String sessionId) => _db
      .collection('sessions')
      .doc(sessionId)
      .collection('records')
      .snapshots()
      .map((snapshot) {
        final records = snapshot.docs
            .map(AttendanceRecord.fromDocument)
            .toList();
        records.sort((a, b) => a.studentName.compareTo(b.studentName));
        return records;
      });

  Stream<List<AppUser>> studentsStream() => _db
      .collection('users')
      .where('role', isEqualTo: 'student')
      .snapshots()
      .map((snapshot) {
        final users = snapshot.docs
            .map(AppUser.fromDocument)
            .where((user) => user.status != UserStatus.deleted)
            .toList();
        users.sort((a, b) => a.fullName.compareTo(b.fullName));
        return users;
      });

  Stream<List<AppUser>> administratorsStream() => _db
      .collection('users')
      .where('role', isEqualTo: 'admin')
      .snapshots()
      .map((snapshot) {
        final users = snapshot.docs.map(AppUser.fromDocument).toList();
        users.sort((a, b) => a.fullName.compareTo(b.fullName));
        return users;
      });

  Future<void> resetStudentPhone(String uid) =>
      _db.collection('users').doc(uid).update({
        'deviceId': FieldValue.delete(),
        'deviceBoundAt': FieldValue.delete(),
        'phoneResetAt': FieldValue.serverTimestamp(),
        'phoneResetBy': _auth.currentUser!.uid,
        'updatedAt': FieldValue.serverTimestamp(),
      });

  Future<void> setStudentDisabled(String uid, {required bool disabled}) =>
      _db.collection('users').doc(uid).update({
        'status': disabled ? 'disabled' : 'active',
        'statusChangedAt': FieldValue.serverTimestamp(),
        'statusChangedBy': _auth.currentUser!.uid,
        'updatedAt': FieldValue.serverTimestamp(),
      });

  Future<void> deleteStudent(String uid) =>
      _db.collection('users').doc(uid).update({
        'status': 'deleted',
        'deletedAt': FieldValue.serverTimestamp(),
        'deletedBy': _auth.currentUser!.uid,
        'deviceId': FieldValue.delete(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

  Future<String> generateAdminInvite() async {
    final code = _newAdminCode();
    final hash = AuthService.hashValue(code);
    await _db.collection('adminInvites').doc(hash).set({
      'createdBy': _auth.currentUser!.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(
        DateTime.now().add(const Duration(hours: 24)),
      ),
      'used': false,
      'revoked': false,
    });
    return code;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> adminInvitesStream() =>
      _db.collection('adminInvites').snapshots();

  Future<void> revokeAdminInvite(String hash) =>
      _db.collection('adminInvites').doc(hash).update({
        'revoked': true,
        'revokedBy': _auth.currentUser!.uid,
        'revokedAt': FieldValue.serverTimestamp(),
      });
}
