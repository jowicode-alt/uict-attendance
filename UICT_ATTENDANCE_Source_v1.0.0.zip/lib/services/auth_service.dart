import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/app_user.dart';
import 'app_constants.dart';
import 'device_service.dart';

class AppAuthException implements Exception {
  const AppAuthException(this.message);
  final String message;

  @override
  String toString() => message;
}

class AuthService {
  AuthService._();

  static final AuthService instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  static const int maxEmbeddedPhotoBytes = 300000;

  Stream<User?> get authChanges => _auth.authStateChanges();
  User? get currentAuthUser => _auth.currentUser;

  static String normalizeStudentNumber(String value) =>
      value.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  static String hashValue(String value) =>
      sha256.convert(utf8.encode(value)).toString();

  static String messageFor(Object error) {
    if (error is AppAuthException) return error.message;
    if (error is FirebaseAuthException) {
      return switch (error.code) {
        'email-already-in-use' => 'That email address is already registered.',
        'invalid-email' => 'Enter a valid email address.',
        'weak-password' =>
          'Use a stronger password with at least 8 characters.',
        'user-not-found' ||
        'wrong-password' ||
        'invalid-credential' => 'The login details are incorrect.',
        'too-many-requests' =>
          'Too many attempts. Wait a moment and try again.',
        'network-request-failed' =>
          'No internet connection. Connect and try again.',
        _ => error.message ?? 'Authentication failed. Please try again.',
      };
    }
    if (error is FirebaseException) {
      return error.message ?? 'The request could not be completed.';
    }
    return 'Something went wrong. Please try again.';
  }

  Future<AppUser> loadCurrentProfile() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) throw const AppAuthException('You are not signed in.');
    final document = await _db.collection('users').doc(uid).get();
    if (!document.exists) {
      throw const AppAuthException(
        'This account has no application profile. Contact an administrator.',
      );
    }
    return AppUser.fromDocument(document);
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> currentProfileStream() {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return const Stream.empty();
    return _db.collection('users').doc(uid).snapshots();
  }

  Future<void> registerStudent({
    required String fullName,
    required String studentNumber,
    required String email,
    required String phone,
    required String password,
    required Uint8List photoBytes,
  }) async {
    if (photoBytes.isEmpty || photoBytes.length > maxEmbeddedPhotoBytes) {
      throw const AppAuthException(
        'The profile photo is too large. Capture it again and try once more.',
      );
    }
    final cleanNumber = normalizeStudentNumber(studentNumber);
    final aliasId = hashValue(cleanNumber);
    final aliasRef = _db.collection('loginAliases').doc(aliasId);
    if ((await aliasRef.get()).exists) {
      throw const AppAuthException(
        'That student or registration number is already registered.',
      );
    }

    UserCredential? credential;
    try {
      credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );
      final uid = credential.user!.uid;
      final deviceId = await DeviceService.instance.getDeviceId();

      final userRef = _db.collection('users').doc(uid);
      final batch = _db.batch();
      batch.set(userRef, {
        'role': 'student',
        'fullName': fullName.trim(),
        'studentNumber': studentNumber.trim().toUpperCase(),
        'normalizedStudentNumber': cleanNumber,
        'email': email.trim().toLowerCase(),
        'phone': phone.trim(),
        'photoBytes': Blob(photoBytes),
        'photoContentType': 'image/jpeg',
        'status': 'active',
        'deviceId': deviceId,
        'deviceBoundAt': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      batch.set(aliasRef, {
        'email': email.trim().toLowerCase(),
        'role': 'student',
        'createdAt': FieldValue.serverTimestamp(),
      });
      await batch.commit();
      await credential.user!.updateDisplayName(fullName.trim());
    } catch (error) {
      try {
        await credential?.user?.delete();
      } catch (_) {
        // The original error is more useful to the user.
      }
      rethrow;
    }
  }

  Future<void> loginStudent({
    required String identifier,
    required String password,
  }) async {
    var email = identifier.trim().toLowerCase();
    if (!email.contains('@')) {
      final normalized = normalizeStudentNumber(identifier);
      final alias = await _db
          .collection('loginAliases')
          .doc(hashValue(normalized))
          .get();
      email = alias.data()?['email'] as String? ?? '';
      if (email.isEmpty) {
        throw const AppAuthException(
          'No student account matches that student number.',
        );
      }
    }
    await _auth.signInWithEmailAndPassword(email: email, password: password);
    try {
      final profile = await loadCurrentProfile();
      if (!profile.isStudent) {
        throw const AppAuthException(
          'Use Administrator Login for this account.',
        );
      }
      if (!profile.isActive) {
        throw AppAuthException(
          profile.status == UserStatus.disabled
              ? 'This student account is disabled. Contact an administrator.'
              : 'This student account has been deleted.',
        );
      }
      final deviceId = await DeviceService.instance.getDeviceId();
      final userRef = _db.collection('users').doc(profile.uid);
      if (profile.deviceId == null || profile.deviceId!.isEmpty) {
        await userRef.update({
          'deviceId': deviceId,
          'deviceBoundAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      } else if (profile.deviceId != deviceId) {
        throw const AppAuthException(
          'This account is registered to another phone. Ask an administrator to use Reset Phone.',
        );
      }
    } catch (_) {
      await _auth.signOut();
      rethrow;
    }
  }

  Future<void> loginAdmin({
    required String email,
    required String password,
  }) async {
    await _auth.signInWithEmailAndPassword(
      email: email.trim().toLowerCase(),
      password: password,
    );
    try {
      final profile = await loadCurrentProfile();
      if (!profile.isAdmin) {
        throw const AppAuthException('Use Student Login for this account.');
      }
      if (!profile.isActive) {
        throw const AppAuthException('This administrator account is disabled.');
      }
    } catch (_) {
      await _auth.signOut();
      rethrow;
    }
  }

  Future<void> registerAdmin({
    required String registrationCode,
    required String fullName,
    required String email,
    required String phone,
    required String password,
  }) async {
    final cleanCode = registrationCode.trim().toUpperCase();
    final codeHash = hashValue(cleanCode);
    final isBootstrap = codeHash == AppConstants.firstAdminCodeHash;
    DocumentReference<Map<String, dynamic>>? inviteRef;

    if (!isBootstrap) {
      inviteRef = _db.collection('adminInvites').doc(codeHash);
      final invite = await inviteRef.get();
      final data = invite.data();
      final expiresAt = data?['expiresAt'] as Timestamp?;
      if (!invite.exists ||
          data?['used'] == true ||
          data?['revoked'] == true ||
          expiresAt == null ||
          expiresAt.toDate().isBefore(DateTime.now())) {
        throw const AppAuthException(
          'That administrator registration code is invalid, expired or already used.',
        );
      }
    }

    UserCredential? credential;
    try {
      credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );
      final uid = credential.user!.uid;
      final userRef = _db.collection('users').doc(uid);
      final batch = _db.batch();
      batch.set(userRef, {
        'role': 'admin',
        'fullName': fullName.trim(),
        'email': email.trim().toLowerCase(),
        'phone': phone.trim(),
        'status': 'active',
        'inviteCodeHash': codeHash,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      if (isBootstrap) {
        batch.set(_db.collection('system').doc('bootstrap'), {
          'firstAdminUid': uid,
          'completedAt': FieldValue.serverTimestamp(),
        });
      } else {
        batch.update(inviteRef!, {
          'used': true,
          'usedBy': uid,
          'usedAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();
      await credential.user!.updateDisplayName(fullName.trim());
    } catch (error) {
      try {
        await credential?.user?.delete();
      } catch (_) {
        // Keep the original registration failure.
      }
      rethrow;
    }
  }

  Future<void> sendPasswordReset(String email) async {
    if (!email.contains('@')) {
      throw const AppAuthException('Enter the account email address first.');
    }
    await _auth.sendPasswordResetEmail(email: email.trim().toLowerCase());
  }

  Future<void> signOut() => _auth.signOut();
}
