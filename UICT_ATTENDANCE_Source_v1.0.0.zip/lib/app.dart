import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'models/app_user.dart';
import 'screens/admin_dashboard.dart';
import 'screens/auth_pages.dart';
import 'screens/student_dashboard.dart';
import 'services/app_constants.dart';
import 'services/auth_service.dart';
import 'services/device_service.dart';
import 'widgets/common.dart';

class UICTAttendanceApp extends StatelessWidget {
  const UICTAttendanceApp({super.key, this.startupError});
  final Object? startupError;

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF0B1F3A);
    const gold = Color(0xFFD5A72E);
    final colorScheme = ColorScheme.fromSeed(
      seedColor: navy,
      brightness: Brightness.light,
      primary: navy,
      secondary: gold,
      surface: const Color(0xFFF7F9FC),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConstants.appName,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: colorScheme,
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(18)),
            side: BorderSide(color: Color(0xFFE2E7EF)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFD7DEE8)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFD7DEE8)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: navy, width: 1.7),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 15,
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: navy,
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
        ),
      ),
      home: startupError == null
          ? const AuthGate()
          : StartupErrorPage(error: startupError!),
    );
  }
}

class StartupErrorPage extends StatelessWidget {
  const StartupErrorPage({super.key, required this.error});
  final Object error;

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const AppMark(size: 92),
            const SizedBox(height: 24),
            Text(
              'App setup could not start',
              style: Theme.of(context).textTheme.headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            const Text(
              'Check the internet connection and Firebase configuration, then reopen the app.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              error.toString(),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.redAccent, fontSize: 12),
            ),
          ],
        ),
      ),
    ),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: AuthService.instance.authChanges,
      builder: (context, authSnapshot) {
        if (authSnapshot.connectionState == ConnectionState.waiting) {
          return const AppLoading(message: 'Starting UICT ATTENDANCE…');
        }
        if (!authSnapshot.hasData) return const LandingPage();
        return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: AuthService.instance.currentProfileStream(),
          builder: (context, profileSnapshot) {
            if (profileSnapshot.hasError) {
              return AccountProblemPage(
                message: profileSnapshot.error.toString(),
              );
            }
            if (!profileSnapshot.hasData) {
              return const AppLoading(message: 'Loading your account…');
            }
            final document = profileSnapshot.data!;
            if (!document.exists) {
              return const AccountProblemPage(
                message: 'This login has no UICT ATTENDANCE profile. Contact an administrator.',
              );
            }
            return ProfileGate(user: AppUser.fromDocument(document));
          },
        );
      },
    );
  }
}

class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key, required this.user});
  final AppUser user;

  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late Future<String?> _deviceCheck;

  @override
  void initState() {
    super.initState();
    _deviceCheck = _checkDevice();
  }

  @override
  void didUpdateWidget(covariant ProfileGate oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.user.deviceId != widget.user.deviceId ||
        oldWidget.user.status != widget.user.status) {
      _deviceCheck = _checkDevice();
    }
  }

  Future<String?> _checkDevice() async {
    if (!widget.user.isStudent) return null;
    final current = await DeviceService.instance.getDeviceId();
    if (widget.user.deviceId == null || widget.user.deviceId!.isEmpty) {
      return 'The registered phone was reset. Log out, then sign in on the phone you want to register.';
    }
    if (widget.user.deviceId != current) {
      return 'This student account is registered to another phone. Ask an administrator to select Reset Phone.';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.user.isActive) {
      return AccountProblemPage(
        message: widget.user.status == UserStatus.disabled
            ? 'This account is disabled. Contact an administrator.'
            : 'This account has been deleted.',
      );
    }
    return FutureBuilder<String?>(
      future: _deviceCheck,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const AppLoading(message: 'Checking registered phone…');
        }
        if (snapshot.hasError) {
          return AccountProblemPage(message: snapshot.error.toString());
        }
        if (snapshot.data != null) {
          return AccountProblemPage(message: snapshot.data!);
        }
        return widget.user.isAdmin
            ? AdminDashboard(user: widget.user)
            : StudentDashboard(user: widget.user);
      },
    );
  }
}

class AccountProblemPage extends StatelessWidget {
  const AccountProblemPage({super.key, required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.lock_person_outlined, size: 72),
            const SizedBox(height: 20),
            Text(
              'Account access unavailable',
              style: Theme.of(context).textTheme.headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w800),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: AuthService.instance.signOut,
              icon: const Icon(Icons.logout),
              label: const Text('Return to login'),
            ),
          ],
        ),
      ),
    ),
  );
}
