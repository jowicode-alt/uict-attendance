import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Object? startupError;
  try {
    await Firebase.initializeApp();
  } catch (error) {
    startupError = error;
  }
  runApp(UICTAttendanceApp(startupError: startupError));
}
