# UICT ATTENDANCE - Client Handover

Release: 1.0.0 (build 1)  
Prepared: 26 August 2026  
Built by: WIZZARD NATION

## Release identity

| Item | Value |
|---|---|
| Application | UICT ATTENDANCE |
| Institution | UICT BBIT |
| Android package | `com.wizzardnation.attendance` |
| iOS bundle ID | `com.wizzardnation.attendance` |
| Firebase project | `attendence-uict-bbit` |
| Android minimum | API 24 (Android 7.0) |
| Android target | API 36 |
| iOS minimum | iOS 15.0 |

## Delivered application

- Signed Android APK for direct installation and acceptance testing
- Signed Android App Bundle for Google Play
- Complete Flutter source for Android and iPhone
- iOS Xcode project with Firebase configuration, icons, splash assets, camera/location descriptions, and Wi-Fi entitlement
- Firestore rules and the required collection-group index
- Private Android upload key and first-administrator registration handover
- Store submission, acceptance testing, privacy, and backend setup documents

## Student experience

- Register with full name, student/registration number, email, phone, password, and a required camera-captured photo compressed for protected Firestore storage
- Log in using email or student number
- See their recognition photo and student number after login
- Use one registered phone; changing phones requires Administrator -> Reset Phone
- Mark attendance using the administrator's rotating QR or six-character backup code
- Pass all checks: administrator-open session, registered phone, approved classroom Wi-Fi, and GPS radius
- View present/absent history and percentage

## Administrator experience

- Register multiple administrators with one-time codes
- Use the separately supplied bootstrap code for the first administrator
- Generate and revoke 24-hour, one-use codes for later administrators
- Configure exact Wi-Fi SSIDs, campus coordinates, and attendance radius in the app
- Open one named session at a time using an atomic multi-admin lock
- Display a QR that refreshes every 30 seconds and a six-character backup code
- Watch verified students appear live with recognition photo and student number
- Use only the approved student actions: Delete, Reset Phone, Disable/Enable
- Close the session and automatically record remaining eligible students as absent
- Review today, month, custom-date, and all-history reports
- Export PDF, Excel, and CSV reports

## Accounts and services

A new Firebase project is not required; this release reuses `attendence-uict-bbit`. Cloud Storage and Cloud Functions are not used. The project may remain on the no-cost Spark plan without a payment method while Firestore usage stays within its free quota. A new GitHub account or repository is not required. An existing Google Play Console account can publish the AAB. iPhone App Store distribution requires a paid Apple Developer team because Apple restricts the Wi-Fi information entitlement to professional development teams.

## Go-live order

1. Complete `FIREBASE_SETUP.md` and deploy all supplied rules and indexes.
2. Register the first administrator using `FIRST_ADMIN_PRIVATE.txt`.
3. In the admin app, save the classroom Wi-Fi, campus coordinates, and radius.
4. Run every physical-device check in `CLIENT_ACCEPTANCE_TEST.md`.
5. Upload the AAB to an internal Google Play test track.
6. Sign the iOS project in Xcode and test through TestFlight on a physical iPhone.
7. Complete store privacy disclosures and publish the final privacy policy.

## Private material

Keep `FIRST_ADMIN_PRIVATE.txt`, `ANDROID_SIGNING_PRIVATE.txt`, `android/key.properties`, and the upload keystore private. Never commit them to a public GitHub repository. Losing the Android upload key can delay or prevent future updates unless Play Console key reset procedures are completed.
