# Build Verification - Release 1.0.0+1

Verified on 26 August 2026.

## Source checks

- Static analysis: 22 source files checked, zero diagnostics
- `flutter test`: 3 tests passed
- Release AOT compilation: passed for armeabi-v7a, arm64-v8a, and x86_64
- Firebase Storage dependency and compiled Storage references: absent
- Firebase/Android JSON configuration: valid JSON
- iOS Info, Firebase, entitlement, and framework property lists: valid XML
- Firebase project ID: `attendence-uict-bbit`
- Android package and iOS bundle ID: `com.wizzardnation.attendance`

## Android APK

- File: `UICT_ATTENDANCE_v1.0.0.apk`
- Size: 84,855,556 bytes
- SHA-256: `e051745e69510732798df952b2b26906b7af6ee002306435dc2c3fe98e354c64`
- Package: `com.wizzardnation.attendance`
- Version: 1.0.0 (code 1)
- Minimum SDK: 24
- Target SDK: 36
- Compile SDK: 37
- APK Signature Scheme v2: verified
- APK Signature Scheme v3: verified
- 16 KB page alignment: verified
- Signer certificate SHA-256: `a011acd1057d468cca02b6518c2929246d32ac20693dc9babe30680cc1e13dc3`

## Android App Bundle

- File: `UICT_ATTENDANCE_v1.0.0.aab`
- Size: 62,100,779 bytes
- SHA-256: `ff9814051726fe0a2015818cd85b588b583a0dfe5b34ddaed96313f96024b09a`
- JAR signature and signed manifest: verified across 463 archive entries
- ZIP integrity: no compressed-data errors

## Requested Android permissions

- Camera
- Fine/coarse foreground location
- Internet
- Network state and Wi-Fi state

No background location or media-library permission is requested.

## iPhone status

The complete Xcode project targets iOS 15.0 and includes the Firebase plist, camera/location descriptions, icons, splash assets, and Access Wi-Fi Information entitlement. A signed IPA cannot be produced without the client's Apple Developer signing identity and a macOS/Xcode signing environment. Final TestFlight validation must use a physical iPhone because the simulator does not return the current Wi-Fi SSID.
