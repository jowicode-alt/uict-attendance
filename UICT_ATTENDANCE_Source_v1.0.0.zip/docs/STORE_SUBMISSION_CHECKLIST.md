# Store Submission Checklist

## Google Play

- [ ] Use a client-owned Google Play Console developer account; no new account is needed if one already exists.
- [ ] Create the app with package `com.wizzardnation.attendance`.
- [ ] Enroll in Play App Signing and upload `UICT_ATTENDANCE_v1.0.0.aab`.
- [ ] Keep the supplied upload keystore and passwords private for future releases.
- [ ] Complete the store listing, support contact, category, content rating, and privacy policy URL.
- [ ] Complete Data safety using the data categories in the privacy draft.
- [ ] Explain camera use (registration photo and QR scan) and precise location use (classroom verification).
- [ ] Upload to Internal testing first and complete the acceptance test on supported Android phones.
- [ ] Promote the same tested release to production after client sign-off.

## Apple App Store / TestFlight

- [ ] Use a paid, client-owned Apple Developer team.
- [ ] Register App ID `com.wizzardnation.attendance`.
- [ ] Enable the Access Wi-Fi Information capability for the App ID and provisioning profile.
- [ ] Open `ios/Runner.xcworkspace` in the current stable Xcode on macOS.
- [ ] Select the client team under Signing & Capabilities and confirm `Runner.entitlements` is active.
- [ ] Confirm `GoogleService-Info.plist` is included in the Runner target.
- [ ] Archive release 1.0.0 (build 1), validate it, and upload to App Store Connect.
- [ ] Complete App Privacy disclosures, privacy-policy URL, support URL, screenshots, age rating, and review notes.
- [ ] Test Wi-Fi verification on a physical iPhone; iOS simulators do not return the current SSID.
- [ ] Release through TestFlight before App Store production.

## GitHub

GitHub is optional and does not affect app operation or publishing. If used, create a private client-owned repository. The included `.gitignore` excludes local SDK paths, build output, Android keys, and signing properties. Do not override those exclusions.

