# UICT ATTENDANCE Privacy Policy - Client Draft

Effective date: 26 August 2026

This draft must be reviewed by UICT BBIT, completed with an official privacy contact and retention period, and published at a public URL before store submission.

## Operator

UICT BBIT operates UICT ATTENDANCE. Privacy contact: **[insert official client email and postal contact]**.

## Information collected

The service may process a student's name, student/registration number, email address, phone number, recognition photograph, attendance records, device-binding identifier, classroom Wi-Fi name, precise location at check-in, location accuracy, and technical authentication/security records. Administrator accounts process name, email, phone number, and administrative actions.

## Why the information is used

Information is used to register and authenticate users, bind a student account to one phone, confirm classroom presence, prevent duplicate or remote attendance, show administrators a recognition photo and student number, calculate attendance percentages, generate reports, secure administrator registration, troubleshoot the service, and meet UICT BBIT academic/administrative obligations.

## When location, Wi-Fi, and camera are used

The camera is used for the registration photo and QR scanning. Precise location and the connected Wi-Fi name are checked when attendance is submitted (and when an administrator captures the approved campus location). The app does not require continuous background location.

## Service providers and disclosure

The application uses Google Firebase Authentication and Cloud Firestore. The compressed recognition photo is held inside the protected student profile in Firestore; Firebase Cloud Storage is not used. UICT BBIT should list its applicable contracts and any other processors here. Information is not intended for advertising or sale. It may be disclosed where required by law, to protect the service, or to authorized institutional staff performing legitimate duties.

## Retention

UICT BBIT should define its approved academic-record retention schedule here: **[insert retention period and deletion procedure]**. Deleting a student in the app blocks account access while retaining historical attendance for authorized reporting. Requests for full account/data erasure require an authorized backend process consistent with institutional and legal retention duties.

## Security

The app uses authenticated access, role-based Firestore rules, one-time administrator codes, a registered-device check, expiring QR proofs, an administrator-controlled session lock, and encrypted network transport. No system can guarantee absolute security; UICT BBIT should restrict console access, protect signing keys, review administrator access, and monitor Firebase usage.

## User choices and rights

Users can decline camera or location permission, but registration or verified attendance may then be unavailable. Users may contact UICT BBIT to request access, correction, restriction, objection, or deletion where applicable, subject to verified identity and lawful institutional retention requirements.

## Children and students

UICT BBIT must confirm the age group and lawful basis for processing before publication. If minors can use the service, the client must add the required guardian/education notices and consent process for its jurisdiction.

## Changes

UICT BBIT may update this policy when the app, legal requirements, or service providers change. The public policy should show the effective date and explain material changes.
