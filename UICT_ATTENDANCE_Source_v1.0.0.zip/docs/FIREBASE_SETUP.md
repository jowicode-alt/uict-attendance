# Firebase Production Setup

The app is already configured for Firebase project `attendence-uict-bbit` and mobile identifier `com.wizzardnation.attendance`. Release 1.0.0 uses Firebase Authentication and Cloud Firestore only. It does not use Cloud Storage or Cloud Functions.

## No billing setup required

The existing project can remain on Firebase's Spark plan. Spark does not require payment information, and Cloud Firestore includes a free usage quota. If that quota is exceeded, the app's Firestore operations pause until quota resets; it does not create a charge. Monitor usage in Firebase Console and upgrade only if the client later chooses to support higher usage.

Official references: [Firebase pricing plans](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans) and [Cloud Firestore free quota](https://firebase.google.com/docs/firestore/pricing).

## 1. Confirm project ownership

Use a Google account owned by the client organization. In Firebase Console, verify that the client has Owner access to `attendence-uict-bbit` and that usage alerts are assigned to client-controlled contacts.

## 2. Enable required services

1. Authentication -> Sign-in method -> enable Email/Password.
2. Firestore Database -> create the default database in Native mode.
3. Project settings -> confirm both registered apps use `com.wizzardnation.attendance`.

The supplied `android/app/google-services.json` and `ios/Runner/GoogleService-Info.plist` already match this project and identifier.

## 3. Deploy rules and index

Install and authenticate the Firebase CLI, then run from the source root:

```bash
npm install -g firebase-tools
firebase login
firebase use attendence-uict-bbit
firebase deploy --only firestore:rules,firestore:indexes
```

The index deployment enables student attendance-history collection-group queries. Wait until Firebase reports that the index is ready before acceptance testing.

## 4. Register the first administrator

1. Install the signed APK or a TestFlight build.
2. Choose Administrator Login -> Register administrator using a code.
3. Use the one-time code in `FIRST_ADMIN_PRIVATE.txt`.
4. Store that private file securely after registration; the same code cannot create another administrator.

All later administrators use codes generated in Administrator Management. Each code works once, expires after 24 hours, and can be revoked before use.

## 5. Configure attendance controls

In Administrator -> More -> Attendance Settings:

1. Enter the classroom Wi-Fi SSID exactly as the phone reports it. SSIDs are case-sensitive.
2. Capture the campus/classroom coordinates while physically at the approved location.
3. Set the radius (default recommendation: 100 metres).
4. Save and test from both inside and outside the permitted area.

## Security behavior

- The bootstrap and generated administrator codes are represented in Firestore only by SHA-256 hashes.
- Admin opening uses an atomic backend lock, so two administrators cannot create overlapping sessions.
- Closing locks new check-ins before absent records are written, preventing close/check-in races.
- Firestore validates the open-session lock, proof hash, student profile, device binding, Wi-Fi SSID, and GPS radius on every student attendance write.
- Each recognition photo is compressed to 300 x 300 JPEG and limited to 300,000 bytes before being stored in the student's Firestore profile.
- Recognition photos are readable in Firestore only by their student or an active administrator.
- Student deletion is a soft deletion so historical attendance remains available for reports.

## Recommended post-launch hardening

Enable Firebase App Check after production signing certificates and Apple configuration are finalized. Start in monitoring mode, review legitimate traffic, and only then enforce it for Firestore.
