# UICT ATTENDANCE 1.0.0

Client rebuild for Android and iPhone using the approved no-billing photo design.

Highlights:

- Student registration with required front-camera recognition photo
- Recognition photos compressed and stored in protected Firestore profiles
- No Firebase Cloud Storage or Cloud Functions dependency
- Firebase Spark plan supported without a payment method while usage remains within free quotas
- Student login by email or registration number
- One registered phone per student with administrator reset
- Multiple administrator registration using one-time codes
- Atomic administrator-open attendance sessions
- Rotating QR and six-character backup code
- Wi-Fi, GPS radius, device, proof, and open-session validation
- Live administrator recognition list with photo and student number
- Automatic absent records on session close
- Daily, monthly, custom, history, and percentage reporting
- PDF, Excel, and CSV export
- Original light login design and UICT ATTENDANCE logo placement preserved
- UICT ATTENDANCE and WIZZARD NATION branding
