# Client Acceptance Test

Run these checks on physical phones before production. Use one administrator phone, at least two student phones, the real classroom Wi-Fi, and a location outside the configured radius.

| ID | Test | Expected result |
|---|---|---|
| A01 | Register first administrator with bootstrap code | Account is created once; code cannot be reused |
| A02 | Generate a later-admin code | Code is shown once, expires in 24 hours, and appears as pending |
| A03 | Register a second administrator | Registration succeeds once; reused code fails |
| A04 | Revoke an unused admin code | Revoked code cannot register an administrator |
| S01 | Register student and deny camera | Registration cannot finish without a photo |
| S02 | Register student with camera photo | Student profile opens with photo and student number |
| S03 | Log in with email | Correct student dashboard opens |
| S04 | Log in with student number | Same student dashboard opens |
| S05 | Log in on a second phone before reset | Access is rejected as another phone |
| S06 | Admin selects Reset Phone, then student logs in on intended phone | New phone binds; old phone no longer passes device check |
| S07 | Admin disables and re-enables student | Login is blocked while disabled and restored when enabled |
| S08 | Admin deletes student | App access remains blocked; historical reports remain |
| T01 | Open session before settings exist | App requires Wi-Fi/GPS configuration |
| T02 | Two admins attempt to open sessions | Only one open session is accepted |
| T03 | Student scans current QR on correct Wi-Fi and inside radius | Attendance saves and appears live with photo/number |
| T04 | Student enters backup code on correct Wi-Fi and inside radius | Attendance saves successfully |
| T05 | Student repeats the same session | Duplicate attendance is rejected |
| T06 | Student uses wrong Wi-Fi | Attendance is rejected |
| T07 | Student is outside GPS radius | Attendance is rejected |
| T08 | Student uses expired/old QR | Attendance is rejected |
| T09 | Admin closes session | QR/code stop working; unmarked eligible students become absent |
| R01 | View today/month/custom/all-history reports | Counts and student percentages match records |
| R02 | Export PDF, Excel, and CSV | Each file opens and contains all filtered records |
| I01 | Repeat T03-T09 on a physical iPhone | Camera, precise location, SSID, QR, and reporting work |

Record device models, OS versions, tester, date, and any failed ID. Production sign-off should be given only after every required row passes.

